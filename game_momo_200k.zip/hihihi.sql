-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 07, 2022 at 12:17 PM
-- Server version: 5.7.38-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sieuthic_momo`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `username` mediumtext NOT NULL,
  `password` mediumtext,
  `api_key` varchar(255) NOT NULL,
  `name` mediumtext NOT NULL,
  `email` mediumtext,
  `phone` mediumtext,
  `time` int(11) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `ip` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `api_key`, `name`, `email`, `phone`, `time`, `datetime`, `ip`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'dytdsadsa', 'Admin', 'admin', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cron_momo`
--

CREATE TABLE `cron_momo` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(6) DEFAULT NULL,
  `Name` mediumtext,
  `email` varchar(255) DEFAULT NULL,
  `imei` varchar(100) DEFAULT NULL,
  `AAID` varchar(100) DEFAULT NULL,
  `TOKEN` varchar(300) DEFAULT NULL,
  `ohash` varchar(100) DEFAULT NULL,
  `SECUREID` varchar(100) DEFAULT NULL,
  `rkey` varchar(100) DEFAULT NULL,
  `rowCardId` varchar(100) DEFAULT NULL,
  `authorization` varchar(2000) NOT NULL DEFAULT 'undefined',
  `agent_id` varchar(100) NOT NULL DEFAULT 'undefined',
  `setupKeyDecrypt` varchar(150) DEFAULT NULL,
  `setupKey` varchar(200) DEFAULT NULL,
  `sessionkey` varchar(150) DEFAULT ' ',
  `RSA_PUBLIC_KEY` mediumtext,
  `BALANCE` int(11) DEFAULT NULL,
  `BankVerify` int(11) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `hardware` varchar(50) DEFAULT NULL,
  `facture` varchar(50) DEFAULT NULL,
  `MODELID` varchar(100) DEFAULT NULL,
  `TimeLogin` int(30) DEFAULT '0',
  `errorDesc` mediumtext,
  `status` varchar(255) DEFAULT NULL,
  `withdraw_status` int(11) NOT NULL DEFAULT '1',
  `share_fund` int(11) NOT NULL DEFAULT '1',
  `today` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `today_gd` int(11) DEFAULT '0',
  `noidungtra` varchar(255) DEFAULT NULL,
  `limit_day` int(11) DEFAULT '30000000',
  `limit_month` int(11) DEFAULT '100000000',
  `ghbank` varchar(100) NOT NULL,
  `try` int(11) NOT NULL DEFAULT '0',
  `DataJson` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `id` int(11) NOT NULL,
  `device` varchar(50) DEFAULT NULL,
  `hardware` varchar(50) DEFAULT NULL,
  `facture` varchar(50) DEFAULT NULL,
  `MODELID` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`id`, `device`, `hardware`, `facture`, `MODELID`) VALUES
(1, 'SM-G532F', 'mt6735', 'samsung', 'samsung sm-g532gmt6735r58j8671gsw'),
(3, 'SM-A102U', 'a10e', 'Samsung', 'Samsung SM-A102U'),
(4, 'SM-A305FN', 'a30', 'Samsung', 'Samsung SM-A305FN'),
(5, 'HTC One X9 dual sim', 'htc_e56ml_dtul', 'HTC', 'HTC One X9 dual sim'),
(6, 'HTC 7060', 'cp5dug', 'HTC', 'HTC HTC_7060'),
(7, 'HTC D10w', 'htc_a56dj_pro_dtwl', 'HTC', 'HTC htc_a56dj_pro_dtwl'),
(8, 'Oppo realme X Lite', 'RMX1851CN', 'Oppo', 'Oppo RMX1851'),
(9, 'MI 9', 'equuleus', 'Xiaomi', 'Xiaomi equuleus');

-- --------------------------------------------------------

--
-- Table structure for table `even`
--

CREATE TABLE `even` (
  `id` int(11) NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  `game` varchar(100) CHARACTER SET utf8 NOT NULL,
  `mota` longtext CHARACTER SET utf8 NOT NULL,
  `moc1` varchar(100) NOT NULL,
  `thuong1` varchar(100) NOT NULL,
  `moc2` varchar(100) NOT NULL,
  `thuong2` varchar(100) NOT NULL,
  `moc3` varchar(100) NOT NULL,
  `thuong3` varchar(100) NOT NULL,
  `moc4` varchar(100) NOT NULL,
  `thuong4` varchar(100) NOT NULL,
  `moc5` varchar(100) NOT NULL,
  `thuong5` varchar(100) NOT NULL,
  `momotra` varchar(100) NOT NULL,
  `trangthai` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `even`
--

INSERT INTO `even` (`id`, `username`, `game`, `mota`, `moc1`, `thuong1`, `moc2`, `thuong2`, `moc3`, `thuong3`, `moc4`, `thuong4`, `moc5`, `thuong5`, `momotra`, `trangthai`) VALUES
(1, 'admin', 'Nhiệm Vụ Ngày', '<p>- Thật tuyệt vời! Mỗi ng&agrave;y chỉ cần chơi tr&ecirc;n&nbsp;<strong>CLMM.ONE</strong>&nbsp;th&igrave; bạn chắc chắn bạn sẽ nhận được tiền thưởng.<br />\r\n- Nhập v&agrave;o số điện thoại của bạn để kiểm tra số tiền đ&atilde; chơi.<br />\r\n<br />\r\n- H&atilde;y nhập số điện thoại của bạn v&agrave;o mục b&ecirc;n tr&ecirc;n để kiểm tra đ&atilde; chơi bao nhi&ecirc;u nh&eacute;. Ch&uacute; &yacute; : Phải nhập sdt l&agrave; số cũ vd: 082xxx -&gt; 0129xxx , 03xxx -&gt; 016...<br />\r\n- Khi chơi đủ mốc tiền, c&aacute;c bạn ấn v&agrave;o nhận thưởng để nhận được c&aacute;c mốc như sau:</p>\r\n', '10000', '1000', '200000', '10000', '500000', '50000', '2000000', '100000', '5000000', '200000', '0787160821', 'run'),
(2, 'admin', 'Giới Thiệu Nhận Thưởng', '', '10000', '1000', '50000', '5000', '100000', '10000', '500000', '20000', '1000000', '50000', '0787160821', 'run');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `name` longtext,
  `mota` longtext,
  `limit_play` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`id`, `username`, `name`, `mota`, `limit_play`, `status`) VALUES
(1, 'admin', 'Chẵn lẻ', '<p>-&nbsp;<strong>Chẵn lẻ</strong>&nbsp;l&agrave; một game t&iacute;nh kết quả bằng&nbsp;<strong>1 số cuối m&atilde; giao dịch</strong>.</p>\r\n\r\n<p><strong>- Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute;</strong></p>\r\n', '1000|100000', 'run'),
(2, 'admin', 'Chẳn Lẻ 2', '<p><strong>-&nbsp;CHẴN LẺ 2 l</strong>&agrave; game t&iacute;nh kết quả bằng&nbsp;<strong>số cuối m&atilde; giao dịch&nbsp;</strong></p>\r\n\r\n<p><strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute;&nbsp;</strong></p>\r\n', '1000|200000', 'run'),
(3, 'admin', 'Tài Xỉu', '<p>-&nbsp;<strong>T&agrave;i Xỉu</strong>&nbsp;l&agrave; một game t&iacute;nh kết quả bằng&nbsp;<strong>1 số cuối m&atilde; giao dịch</strong>.</p>\r\n\r\n<p>-&nbsp;<strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute;</strong></p>\r\n', '1000|100000', 'run'),
(4, 'admin', 'Tài xỉu 2', '<p><strong>- T&agrave;i xỉu 2&nbsp;l</strong>&agrave; game t&iacute;nh kết quả bằng <strong>số cuối m&atilde; giao dịch&nbsp;</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute;</strong>&nbsp;</p>\r\n', '1000|200000', 'run'),
(5, 'admin', 'Tổng 3 Số', '<p>- <strong>Tổng 3 số</strong>&nbsp;l&agrave; game v&ocirc; c&ugrave;ng dễ lấy <strong>Tổng 3 số cuối m&atilde; giao dịch&nbsp;</strong>l&agrave;m kết quả&nbsp;</p>\r\n\r\n<p><strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute; .</strong></p>\r\n', '1000|100000', 'run'),
(6, 'admin', '1 phần 3', '<p>-&nbsp;<strong>1 phần 3</strong>&nbsp;l&agrave; một game t&iacute;nh kết quả bằng&nbsp;1&nbsp;<strong>số cuối m&atilde; giao dịch&nbsp;</strong></p>\r\n\r\n<p><strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute; .</strong></p>\r\n', '1000|100000', 'run'),
(25, 'admin', 'Gấp 3', '<p>-&nbsp;<strong>Gấp 3</strong>&nbsp;l&agrave; một game v&ocirc; c&ugrave;ng dễ, t&iacute;nh kết quả bằng&nbsp;<strong>2 số cuối m&atilde; giao dịch</strong>.</p>\r\n\r\n<p><strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute; .</strong></p>\r\n', '1000|100000', 'run'),
(26, 'admin', 'Lô', '<p>-&nbsp;<strong>L&ocirc;</strong>&nbsp;l&agrave; một game t&iacute;nh kết quả bằng&nbsp;<strong>2 số cuối m&atilde; giao dịch</strong>.</p>\r\n\r\n<p><strong>Mỗi game c&oacute; hạn mức kh&aacute;c nhau n&ecirc;n anh em ch&uacute; &yacute; .</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n', '1000|100000', 'run'),
(30, 'admin', 'H3', '<p>-&nbsp;<strong>H3</strong>&nbsp;l&agrave; một game t&iacute;nh kết quả bằng&nbsp;<strong>hiệu 2 số cuối m&atilde; giao dịch</strong>.</p>\r\n\r\n<p>- Nếu m&atilde; giao dịch c&oacute; hiệu của 2 số&nbsp;<strong>(số trước trừ số sau)</strong>&nbsp;tr&ugrave;ng 1 trong những số tr&ecirc;n bạn sẽ chiến thắng.</p>\r\n', '1000|100000', 'run'),
(31, 'admin', 'Thịnh', '<p>Game của thịnh</p>\r\n', '10000/2000000', 'run');

-- --------------------------------------------------------

--
-- Table structure for table `game_option`
--

CREATE TABLE `game_option` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `game_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `ratio` varchar(11) DEFAULT NULL,
  `number_comment` int(11) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `game_option`
--

INSERT INTO `game_option` (`id`, `username`, `game_id`, `status`, `comment`, `result`, `ratio`, `number_comment`, `type`) VALUES
(10, 'admin', 1, 'run', 'c', '2,4,6,8', '2.4', 1, 1),
(12, 'admin', 3, 'run', 't', '5,6,7,8', '2.4', 1, 1),
(13, 'admin', 3, 'run', 'x', '1,2,3,4', '2.4', 1, 1),
(16, 'admin', 5, 'run', 's', '9,19', '4', 3, 0),
(17, 'admin', 5, 'run', 's', '8,18', '3', 3, 0),
(18, 'admin', 5, 'run', 's', '7,17,27', '2', 3, 0),
(42, 'admin', 2, 'run', 'c2', '0,2,4,6,8', '1.9', 1, 1),
(43, 'admin', 2, 'run', 'l2', '1,3,5,7,9', '1.9', 1, 1),
(44, 'admin', 1, 'run', 'l', '1,3,5,7', '2.4', 1, 1),
(45, 'admin', 6, 'run', 'n3', '7,8,9', '3', 1, 1),
(46, 'admin', 6, 'run', 'n2', '4,5,6', '3', 1, 1),
(47, 'admin', 6, 'run', 'n1', '1,2,3', '3', 1, 1),
(59, 'admin', 25, 'run', 'g3', '123,234,456,678,789', '5', 3, 1),
(60, 'admin', 25, 'run', 'g3', '69,66,99', '4', 2, 1),
(61, 'admin', 25, 'run', 'g3', '02,13,17,19,21,29,35,37,45,46,51,54,57,63,64,74,83,91,95,96	', '3', 2, 1),
(62, 'admin', 26, 'run', 'lo', '01,03,12,19,23,24,30,33,39,48,54,55,60,61,71,81,82,83,67,88,76,64', '3', 2, 1),
(74, 'admin', 30, 'run', 'h3', '5', '3', 2, 2),
(75, 'admin', 30, 'run', 'h3', '7', '4', 2, 2),
(76, 'admin', 30, 'run', 'h3', '9', '5', 2, 2),
(82, 'admin', 4, 'run', 't2', '5,6,7,8,9', '1.9', 1, 1),
(83, 'admin', 4, 'run', 'x2', '0,1,2,3,4', '1.9', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `momo_history`
--

CREATE TABLE `momo_history` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `id_momo` varchar(100) NOT NULL,
  `id_tran` varchar(255) NOT NULL,
  `type` int(11) DEFAULT '0',
  `partnerId` varchar(100) NOT NULL,
  `partnerName` text NOT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `amount_paid` int(11) DEFAULT '0',
  `comment` varchar(100) DEFAULT NULL,
  `game` longtext,
  `actions` longtext,
  `full_data` longtext,
  `time_tran` bigint(20) NOT NULL DEFAULT '0',
  `time_tran_date` mediumtext NOT NULL,
  `status` int(11) DEFAULT '0',
  `status_momo` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `try` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `send`
--

CREATE TABLE `send` (
  `id` int(11) NOT NULL,
  `momo_id` varchar(255) DEFAULT NULL,
  `tranId` varchar(11) NOT NULL,
  `partnerId` varchar(11) NOT NULL,
  `partnerName` text NOT NULL,
  `amount` varchar(10) NOT NULL,
  `comment` mediumtext NOT NULL,
  `time` mediumtext NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(32) NOT NULL,
  `status` varchar(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `balance` int(11) DEFAULT '0',
  `ownerNumber` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `data` mediumtext NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `status` varchar(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `keywords` longtext,
  `notice` longtext,
  `apikey` varchar(100) NOT NULL,
  `top` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `zalo` varchar(255) DEFAULT NULL,
  `tele` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `luuy` longtext,
  `username` varchar(255) NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `block_list` longtext,
  `custom_footer` longtext,
  `hidden_history` varchar(11) NOT NULL DEFAULT '0',
  `sapxep` varchar(100) NOT NULL,
  `soluong` varchar(100) NOT NULL,
  `auto_paid` int(11) NOT NULL DEFAULT '0',
  `view_top` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `status`, `title`, `description`, `keywords`, `notice`, `apikey`, `top`, `video`, `zalo`, `tele`, `logo`, `luuy`, `username`, `color`, `block_list`, `custom_footer`, `hidden_history`, `sapxep`, `soluong`, `auto_paid`, `view_top`) VALUES
(1, '1', 'Hệ thống chẳn lẻ MoMo uy tín giao dịch tự động 24/7', 'Chẳn lẻ momo - Uy tín , giao dịch tự động 24/7 - bank 30s !', 'Chẳn lẻ momo', '<h2>Ch&agrave;o mừng bạn đến với hệ thống Chẵn Lẻ MoMo !</h2>\r\n\r\n<p><img alt=\"\" src=\"https://i.imgur.com/jDPrfSy.png\" style=\"height:100%; width:100%\" /></p>\r\n\r\n<p>Trước khi chơi, bạn n&ecirc;n đọc kĩ những lưu &yacute; sau, nếu bỏ qua những lưu &yacute; n&agrave;y, th&igrave; khi&nbsp;<em>mất tiền, <strong>CLMM.ONE</strong></em>&nbsp;sẽ&nbsp;<em>kh&ocirc;ng chịu tr&aacute;ch nhiệm</em>.</p>\r\n\r\n<p>1. Chẵn lẻ t&agrave;i xỉu số cuối m&atilde; giao dịch l&agrave; 0, 9 thua, nếu muốn c&oacute; 0 v&agrave; 9 vui l&ograve;ng chơi chẵn lẻ 2.</p>\r\n\r\n<p>2. Mỗi số tr&ecirc;n web chỉ c&oacute; thể giao dịch tối đa 25tr hoặc 150 lần một ng&agrave;y. V&igrave; vậy, số tr&ecirc;n hệ thống sẽ thay đổi li&ecirc;n tục n&ecirc;n trước khi chơi bạn n&ecirc;n l&ecirc;n lấy số trước, tr&aacute;nh việc thắng m&agrave; chỉ được ho&agrave;n tiền v&agrave; mất tiền nếu thua.</p>\r\n\r\n<p>✓ Chuyển sai nội dung (kh&ocirc;ng được ho&agrave;n tiền).</p>\r\n\r\n<p>✓&nbsp;Sai hạn mức được ho&agrave;n tiền chơi (nếu thắng).</p>\r\n\r\n<p>✓ Chuyển nhầm số bảo tr&igrave; được trả thưởng (nếu thắng).</p>\r\n\r\n<p><em>Khi bạn tắt ch&uacute; &yacute; n&agrave;y đi, đồng nghĩa với việc bạn đ&atilde; đọc v&agrave; chấp nhận những điều đ&oacute;!</em></p>\r\n', '5fd470e2-fb32-4f9c-96c2-0456bcbada84', '3000000,2000000,1000000,500000,300000', 'https://www.youtube.com/watch?v=tEMhBqHVwuE', '#', '#', 'https://i.imgur.com/hpAhJmZ.png', '<p>Nội dung chuyển kh&ocirc;ng ph&acirc;n biệt in hoa, thường.c&aacute;c đơn sai hạn mức sẽ chỉ được ho&agrave;n gốc với đơn thắng, đơn sai nội dung ko đươc ho&agrave;n</p>\r\n\r\n<p>Nếu bạn chiến thắng, vui l&ograve;ng chờ 5-10s&nbsp;hệ thống sẽ tự động chuyển tiền cho bạn.</p>\r\n\r\n<p><strong>Nếu qu&aacute; 10p chưa nhận được tiền vui l&ograve;ng d&aacute;n m&atilde; v&agrave;o dưới đ&acirc;y để kiểm tra hoặc li&ecirc;n hệ với admin zalo&nbsp;&nbsp;để được hỗ trợ</strong></p>\r\n', 'admin', '#055fb3', '0868224901,0126250673', '', '1', '1', '10', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `topup`
--

CREATE TABLE `topup` (
  `id` int(11) NOT NULL,
  `momo_id` varchar(255) DEFAULT NULL,
  `tranId` varchar(11) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `time` mediumtext NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(32) NOT NULL,
  `status` varchar(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `balance` int(11) DEFAULT NULL,
  `ownerNumber` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `data` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cron_momo`
--
ALTER TABLE `cron_momo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `even`
--
ALTER TABLE `even`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_option`
--
ALTER TABLE `game_option`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `momo_history`
--
ALTER TABLE `momo_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_momo` (`id_momo`);

--
-- Indexes for table `send`
--
ALTER TABLE `send`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topup`
--
ALTER TABLE `topup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cron_momo`
--
ALTER TABLE `cron_momo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `even`
--
ALTER TABLE `even`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `game`
--
ALTER TABLE `game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `game_option`
--
ALTER TABLE `game_option`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `momo_history`
--
ALTER TABLE `momo_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `send`
--
ALTER TABLE `send`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `topup`
--
ALTER TABLE `topup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
