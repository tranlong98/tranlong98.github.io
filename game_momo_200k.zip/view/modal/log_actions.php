<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$id = junoo_boc(GET('id'));
$result = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id` = '".$id."' AND `user_id` = '".$accounts['username']."' ORDER BY `id` DESC LIMIT 1",1);
if(!$result['id']) {
   die('Cút'); 
}
$data_game = json_decode($result['actions'],true);
foreach($data_game as $key => $value){
?>
<div class="alert alert-secondary" role="alert"><?=date("d-m-Y H:i:s",$value['time'])?>: <?=$value['person']?> - <?=$value['text']?></div>
<?php }?>