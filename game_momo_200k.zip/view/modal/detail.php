<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$id = junoo_boc(GET('id'));
$result = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id` = '".$id."' AND `user_id` = '".$accounts['username']."' ORDER BY `id` DESC LIMIT 1",1);
if(!$result['id']) {
   die('Cút'); 
}
$data_game = json_decode($result['game'],true)[0];
?>
<!--begin::Form-->
<form id="edit-form<?=$id?>" action="" accept-charset="UTF-8" class="form">
   <input type="hidden" name="edit_id" id="edit_id" value="<?=$id?>" class="form-control is-valid" />
   <input type="hidden" name="user_id" id="user_id" value="<?=$accounts['username']?>" class="form-control is-valid" />
   <div class="card-body">
      <div class="form-group row ">
         <label class="col-form-label col-lg-3">Mã GD: 
         </label>
         <div class="col-lg-9">
            <input type="text" name="id_tran" id="id_tran" value="<?=$result['id_tran']?>" disabled class="form-control is-valid" />
         </div>
      </div>
      <div class="form-group row ">
         <label class="col-form-label col-lg-3">Trạng thái: 
         </label>
         <div class="col-lg-9">
            <input type="text" name="trangthai" id="trangthai" value="<?=$data_game['text']?>" disabled class="form-control is-valid" />
         </div>
      </div>
      <div class="form-group row ">
         <label class="col-form-label col-lg-3">Số tiền chơi:
         </label>
         <div class="col-lg-9">
            <input type="number" name="amount" id="amount" value="<?=$data_game['amount']?>"  class="form-control is-valid" />
            <div class="valid-feedback">Lưu ý số tiền ko được thay đổi nếu ko cần thiết</div>
         </div>
      </div>
      <div class="form-group row ">
         <label class="col-form-label col-lg-3">Số tiền win:
         </label>
         <div class="col-lg-9">
            <input type="number" name="amount_win" id="amount_win" value="<?=$data_game['amount_win']?>"  class="form-control is-valid" readonly/>
         </div>
      </div>
      <div class="form-group row ">
         <label class="col-form-label col-lg-3">Tỉ lệ:
         </label>
         <div class="col-lg-9">
            <input type="text" name="ratio" id="ratio" value="<?=$data_game['ratio']?>" onchange="tinhtien(this.value,document.getElementById('amount').value)" class="form-control is-valid" />
         </div>
      </div>
      <div class="form-group row ">
         <label class="col-form-label col-lg-3">SĐT: 
         </label>
         <div class="col-lg-9">
            <select class="form-control is-valid" name="phone" id="phone">
               <?php 
                  $getdl = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `user_id` = '".$accounts['username']."'",0);
                  foreach($getdl as $value){
                  ?>
               <option value="<?=$value['phone']?>" <?php if($value['phone'] == $result['phone']) { ?>selected<?php }?>><?=$value['phone']?> - <?=number_format($value['BALANCE'])?>đ </option>
               <?php } ?>
            </select>
         </div>
      </div>
            <div class="form-group row ">
         <label class="col-form-label col-lg-3">Hành Động: 
         </label>
         <div class="col-lg-9">
            <select class="form-control is-valid" name="action" id="action">
                <option value="" >Chọn hành động</option>
                <option value="1" >Trả (trả tay)</option>
                <option value="2" >Hoàn tiền(trả gốc)</option>
                <option value="3" >Hoàn thành(đơn thăng)</option>
                <option value="4" >Hoàn thành(đơn thua)</option>
            </select>
         </div>
      </div>
      
   </div>
</form>
<!--end::Form-->