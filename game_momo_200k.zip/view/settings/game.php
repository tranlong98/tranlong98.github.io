<?php 
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
   require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/view/head.php');
   if(!is_client()){
       load_url('/quanly');
   }
   
$id = junoo_boc(GET('id'));
$result = $db->fetch_assoc("SELECT * FROM `game` WHERE `id` = '".$id."' AND `username` = '".$accounts['username']."' ORDER BY `id` DESC LIMIT 1",1);
if(!$result['id']) {
   load_url('/quanly'); 
}
?>
<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
  <!--begin::Subheader-->
  <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
      <!--begin::Info-->
      <div class="d-flex align-items-center flex-wrap mr-1">
        <!--begin::Page Heading-->
        <div class="d-flex align-items-baseline flex-wrap mr-5">
          <!--begin::Page Title-->
          <h5 class="text-dark font-weight-bold my-1 mr-5">Game Settings #<?=$id?> </h5>
          <!--end::Page Title-->
          <!--begin::Breadcrumb-->
          <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
            <!--<li class="breadcrumb-item text-muted"><a href="" class="text-muted">Features</a></li><li class="breadcrumb-item text-muted"><a href="" class="text-muted">Layout Builder</a></li>-->
          </ul>
          <!--end::Breadcrumb-->
        </div>
        <!--end::Page Heading-->
      </div>
      <!--end::Info-->
      <!--begin::Toolbar-->
      <div class="d-flex align-items-center"></div>
      <!--end::Toolbar-->
    </div>
  </div>
  <!--end::Subheader-->
  <!--begin::Entry-->
  <div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">

      <!--begin::Card-->
      <div class="card card-custom">
        <!--begin::Header-->
        <div class="card-header card-header-tabs-line">
          <ul class="nav nav-dark nav-bold nav-tabs nav-tabs-line" data-remember-tab="tab_id" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="tab" href="#GameSettings">Game Settings #<?=$id?> </a>
            </li>
          </ul>
        </div>
        <!--end::Header-->
        <!--begin::Form-->
          <form id="edit-form" action="" accept-charset="UTF-8" class="form">
            <input type="hidden" name="id" id="id" value="<?=$id?>" class="form-control is-valid" />
            <div class="card-body">
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Tên: <span class="text-danger">*</span>
                </label>
                <div class="col-lg-9">
                  <input type="text" name="name" id="name" value="<?=$result['name']?>" class="form-control is-valid" />
                  <div class="valid-feedback">Tên game</div>
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Mô tả: <span class="text-danger">*</span>
                </label>
                <div class="col-lg-9">
                  <textarea type="text" rows="5" col="5" name="mota" id="mota" class="form-control is-valid"><?=$result['mota']?></textarea>
                  <div class="valid-feedback">Mô tả</div>
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Giới hạn: <span class="text-danger">*</span>
                </label>
                <div class="col-lg-9">
                    <input type="text" name="limit_play" id="limit_play" value="<?=$result['limit_play']?>" class="form-control is-valid" />
                 
                  <div class="valid-feedback">Giới hạn có dạng : 1000|5000</div>
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Trạng Thái: <span class="text-danger">*</span>
                </label>
                <div class="col-lg-9">
                  <select class="form-control is-valid" name="status" id="status">
                    <option value="run" <?php if($result['status'] == 'run'){ ?> selected <?php }?>>Đang Chạy </option>
                    <option value="stop" <?php if($result['status'] == 'stop'){ ?> selected <?php }?>>Ngưng Chạy </option>
                  </select>
                  <div class="valid-feedback">Trạng thái</div>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <div class="row">
                <div class="col-lg-9 ml-lg-auto">
                  <button type="submit" id="submit" name="submit" class="btn btn-primary font-weight-bold mr-2">Submit</button>
                </div>
              </div>
            </div>
          </form>
          <!--end::Form-->
      </div>
      <!--end::Card-->
    </div>
    <!--end::Container-->
  </div>
  <!--end::Entry-->
</div>
<!--end::Content-->
<!--begin::Page Scripts(used by this page)-->
<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
</script>
<!--end::Page Scripts-->
<script>
  CKEDITOR.replace('mota');

  function CKupdate() {
    for (instance in CKEDITOR.instances) CKEDITOR.instances[instance].updateElement();
  }
</script>
<script>
  $(document).on("keypress", function(e) {
    if (e.which == 13) {
      $("#submit").click();
    }
  });
  $(document).ready(function() {
    $("#submit").click(function() {
      CKupdate();
      document.getElementById("submit").disabled = true;
      var zData = $("#edit-form").serialize();
      $.ajax({
        type: "POST",
        url: "/api/settings/game/settings",
        data: zData,
        success: function(result1) {
          document.getElementById("submit").disabled = false;
          result = JSON.parse(result1);
          if (result.status == "success") {
            swal.fire({
              text: result.msg,
              icon: "success",
              buttonsStyling: false,
              confirmButtonText: "Ok, got it!",
              customClass: {
                confirmButton: "btn font-weight-bold btn-light-primary"
              }
            }).then(function() {
	               KTUtil.scrollTop();
	               window.location.href = "";
	       });
          } else {
            swal.fire({
              text: result.msg,
              icon: "error",
              buttonsStyling: false,
              confirmButtonText: "Ok, got it!",
              customClass: {
                confirmButton: "btn font-weight-bold btn-light-primary"
              }
            }).then(function() {
	               KTUtil.scrollTop();
	               window.location.href = "";
	       });
          }
        },
      });
    });
  });
</script>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/view/foot.php');
?>