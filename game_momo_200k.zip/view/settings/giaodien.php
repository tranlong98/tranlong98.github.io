<?php 
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
   require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/view/head.php');
      $settings = $db->fetch_assoc("SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1", 1);
    $api = $settings['apikey'];
    $domain = $_SERVER['HTTP_HOST'];
   $tran = json_decode(hsd($api,$domain), true);
    $hsd = $tran['hsd'];
    $uid = $tran['uid'];
    $time = time();
    $hsd1 = ($hsd - $time) / 86400;
    $floored = floor($hsd1);


   if(!is_client()){
       load_url('/quanly');
   }
   $result = $db->fetch_assoc("SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1", 1);
?>


<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
  <!--begin::Subheader-->
  <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
      <!--begin::Info-->
      <div class="d-flex align-items-center flex-wrap mr-1">
        <!--begin::Page Heading-->
        <div class="d-flex align-items-baseline flex-wrap mr-5">
          <!--begin::Page Title-->
          <h5 class="text-dark font-weight-bold my-1 mr-5">Settings</h5>
          <!--end::Page Title-->
          <!--begin::Breadcrumb-->
          <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
            <!--<li class="breadcrumb-item text-muted"><a href="" class="text-muted">Features</a></li><li class="breadcrumb-item text-muted"><a href="" class="text-muted">Layout Builder</a></li>-->
          </ul>
          <!--end::Breadcrumb-->
        </div>
        <!--end::Page Heading-->
      </div>
      <!--end::Info-->
      <!--begin::Toolbar-->
      <div class="d-flex align-items-center"></div>
      <!--end::Toolbar-->
    </div>
  </div>
  <!--end::Subheader-->
  <!--begin::Entry-->
  <div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
      <!--begin::Notice-->

      <!--end::Notice-->
      <!--begin::Card-->
      <div class="card card-custom">
        <!--begin::Header-->
        <div class="card-header card-header-tabs-line">
          <ul class="nav nav-dark nav-bold nav-tabs nav-tabs-line" data-remember-tab="tab_id" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="tab" href="#MomoSettings">Settings</a>
            </li>
          </ul>
        </div>
        <!--end::Header-->
        <!--begin::Form-->
          <form id="edit-form" action="" accept-charset="UTF-8" class="form">
            <input type="hidden" name="edit_id" id="edit_id" value="<?=$id?>" class="form-control is-valid" />
            <div class="card-body">
                <div class="form-group row ">
                <label class="col-form-label col-lg-3">API KEY KÍCH HOẠT WEB:</label>
                <div class="col-lg-9">
                  <input type="text" name="apikey" id="apikey" value="<?=$result['apikey']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Title:</label>
                <div class="col-lg-9">
                  <input type="text" name="title" id="title" value="<?=$result['title']?>" class="form-control" />
                </div>
              </div>
              
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Description:</label>
                <div class="col-lg-9">
                  <input type="text" name="description" id="description" value="<?=$result['description']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Keywords:</label>
                <div class="col-lg-9">
                  <input type="text" name="keywords" id="keywords" value="<?=$result['keywords']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Logo:</label>
                <div class="col-lg-9">
                  <input type="text" name="logo" id="logo" value="<?=$result['logo']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Lưu ý:</label>
                <div class="col-lg-9">
                  <textarea type="text" name="luuy" id="luuy" class="form-control" /><?=$result['luuy']?></textarea>
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Thông báo:</label>
                <div class="col-lg-9">
                  <textarea type="text" name="notice" id="notice" class="form-control" /><?=$result['notice']?></textarea>
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Custom Footer:</label>
                <div class="col-lg-9">
                    <textarea type="text" rows="10" name="custom_footer" id="custom_footer" class="form-control" /><?=$result['custom_footer']?></textarea>
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Mã màu:</label>
                <div class="col-lg-9">
                  <input type="color" name="color" id="color" value="<?=$result['color']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Thưởng top:</label>
                <div class="col-lg-9">
                  <input type="text" name="top" id="top" value="<?=$result['top']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Video:</label>
                <div class="col-lg-9">
                  <input type="text" name="video" id="video" value="<?=$result['video']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Nhóm zalo:</label>
                <div class="col-lg-9">
                  <input type="text" name="zalo" id="zalo" value="<?=$result['zalo']?>" class="form-control" />
                </div>
              </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Nhóm tele:</label>
                <div class="col-lg-9">
                  <input type="text" name="tele" id="tele" value="<?=$result['tele']?>" class="form-control" />
                </div>
              </div>
               <div class="form-group row">
                    <label class="col-3 col-form-label">Ẩn LSGD:</label>
                        <div class="col-3">
                            <span class="switch switch-icon">
                    <label>
                        <input type="checkbox" <?php if($result['hidden_history'] == 1){ ?> checked="checked" <?php }?> name="hidden_history" id="hidden_history"/>
                        <span></span>
                    </label>
                    </span>
                </div></div>
                <div class="form-group row ">
                <label class="col-form-label col-lg-3">Số lượng giao dịch:</label>
                <div class="col-lg-9">
                  <input type="text" name="soluong" id="soluong" value="<?=$result['soluong']?>" class="form-control" />
                </div>
              </div>
                <div class="form-group row ">
                <label class="col-form-label col-lg-3">Kiểu hiểm thị lịch sử: <span class="text-danger">*</span>
                </label>
                <div class="col-lg-9">
                  <select class="form-control" name="sapxep" id="sapxep">
                    <option value="1" <?php if($result['sapxep'] == '1'){ ?> selected <?php }?>>Random</option>
                    <option value="0" <?php if($result['sapxep'] == '0'){ ?> selected <?php }?>>Thứ tự</option>
                  </select>
                  <p>Bạn chọn ramdom đồng nghĩa hệ thống sẽ tự tạo thời gian ảo cho giao dịch giúp tăng hiệu ứng đông khách cho web</p>
                </div>
                
            </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Top: <span class="text-danger">*</span>
                </label>
                <div class="col-lg-9">
                  <select class="form-control" name="view_top" id="view_top">
                    <option value="1" <?php if($result['view_top'] == '1'){ ?> selected <?php }?>>Tuần</option>
                    <option value="0" <?php if($result['view_top'] == '0'){ ?> selected <?php }?>>Tháng</option>
                  </select>
                </div>
            </div>
              <div class="form-group row ">
                <label class="col-form-label col-lg-3">Block List:</label>
                <div class="col-lg-9">
                    <textarea type="text" name="block_list" id="block_list" class="form-control" /><?=$result['block_list']?></textarea>
                </div>
              </div>
            <div class="card-footer">
              <div class="row">
                <div class="col-lg-9 ml-lg-auto">
                  <button type="submit" id="submit" name="submit" class="btn btn-primary font-weight-bold mr-2">Submit</button>
                </div>
              </div>
            </div>
          </form>
          <!--end::Form-->
      </div>
      <!--end::Card-->
    </div>
    <!--end::Container-->
  </div>
  <!--end::Entry-->
</div></div>

<!--end::Content-->
<!--begin::Page Scripts(used by this page)-->
<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>

<!--end::Page Scripts-->
<script>
  CKEDITOR.replace('luuy');
  CKEDITOR.replace('notice');
  function CKupdate() {
    for (instance in CKEDITOR.instances) CKEDITOR.instances[instance].updateElement();
  }
</script>
<script>
  $(document).on("keypress", function(e) {
    if (e.which == 13) {
      $("#submit").click();
    }
  });
  $(document).ready(function() {
    $("#submit").click(function() {
      CKupdate();
      document.getElementById("submit").disabled = true;
      var zData = $("#edit-form").serialize();
      $.ajax({
        type: "POST",
        url: "/api/settings/giaodien",
        data: zData,
        success: function(result1) {
          document.getElementById("submit").disabled = false;
          result = JSON.parse(result1);
          if (result.status == "success") {
            swal.fire({
              text: result.msg,
              icon: "success",
              buttonsStyling: false,
              confirmButtonText: "Ok, got it!",
              customClass: {
                confirmButton: "btn font-weight-bold btn-light-primary"
              }
            }).then(function() {
	               //KTUtil.scrollTop();
	               window.location.href = "";
	       });
          } else {
            swal.fire({
              text: result.msg,
              icon: "error",
              buttonsStyling: false,
              confirmButtonText: "Ok, got it!",
              customClass: {
                confirmButton: "btn font-weight-bold btn-light-primary"
              }
            }).then(function() {
	               //KTUtil.scrollTop();
	               window.location.href = "";
	       });
          }
        },
      });
    });
  });
  
</script>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/view/foot.php');
?>