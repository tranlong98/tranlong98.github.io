<?php
   require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
   require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/view/head.php');
      
   if(!is_client()){
       load_url('/');
   }
?>

<!--begin::Content-->
	<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	  <!--begin::Subheader-->
	  <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
	    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
	      <!--begin::Info-->
	      <div class="d-flex align-items-center flex-wrap mr-1">
	        <!--begin::Page Heading-->
	        <div class="d-flex align-items-baseline flex-wrap mr-5">
	          <!--begin::Page Title-->
	          <h5 class="text-dark font-weight-bold my-1 mr-5">Thống kê</h5>
	          <!--end::Page Title-->
	          <!--begin::Breadcrumb-->
	          <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
	            <!--<li class="breadcrumb-item text-muted"><a href="" class="text-muted">Features</a></li><li class="breadcrumb-item text-muted"><a href="" class="text-muted">Layout Builder</a></li>-->
	          </ul>
	          <!--end::Breadcrumb-->
	        </div>
	        <!--end::Page Heading-->
	      </div>
	      <!--end::Info-->
	      <!--begin::Toolbar-->
	      <div class="d-flex align-items-center"></div>
	      <!--end::Toolbar-->
	    </div>
	  </div>
	  <!--end::Subheader-->
						<!--begin::Entry-->
						<div class="d-flex flex-column-fluid">
							<!--begin::Container-->
							<div class="container">

								<!--begin::Row-->
								<div class="row">
									<div class="col-lg-12">
										<!--begin::Card-->
										<div class="card card-custom gutter-b">
											<div class="card-header">
												<div class="card-title">
													<h3 class="card-label">Thống Kê Ngày</h3>
												</div>
											</div>
											<div class="card-body">
												<!--begin::Chart-->
												<div id="chart_2"></div>
												<!--end::Chart-->
											</div>
										</div>
										<!--end::Card-->
									</div>
									<div class="col-lg-12">
										<!--begin::Card-->
										<div class="card card-custom gutter-b">
											<div class="card-header">
												<div class="card-title">
													<h3 class="card-label">Thống Kê Tháng</h3>
												</div>
											</div>
											<div class="card-body">
												<!--begin::Chart-->
												<div id="chart_3"></div>
												<!--end::Chart-->
											</div>
										</div>
										<!--end::Card-->
									</div>
									<!--end::Row-->
								</div>
								<!--end::Dashboard-->
							</div>
							<!--end::Container-->
						</div>
						
  <div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
      <!--begin::Card-->
      <div class="card card-custom">
        <div class="card-header flex-wrap border-0 pt-6 pb-0">
          <div class="card-title">
            <h3 class="card-label">Top Ngày</h3>
          </div>
          <div class="card-toolbar">
          </div>
        </div>
        <div class="card-body">
          <!--begin::Search Form-->
          <div class="mb-7">
            <div class="row align-items-center">
              <div class="col-lg-9 col-xl-8">
                <div class="row align-items-center">
                  <div class="col-md-4 my-2 my-md-0">
                    <div class="input-icon">
                      <input type="text" class="form-control" placeholder="Search..." id="kt_datatable1_search_query" />
                      <span>
                        <i class="flaticon2-search-1 text-muted"></i>
                      </span>
                    </div>
                  </div>
                  
                </div>
              </div>
              <div class="col-lg-3 col-xl-4 mt-5 mt-lg-0">
                <a href="#kt_his1" class="btn btn-light-primary px-6 font-weight-bold">Search</a>
              </div>
            </div>
          </div>
          <!--end::Search Form-->
          <!--begin: Datatable-->
          <div class="datatable datatable-bordered datatable-head-custom" id="kt_datatable1"></div>
          <!--end: Datatable-->
        </div>
      </div>
      <!--end::Card-->
    </div>
    <!--end::Container-->
  </div>
  <!--end::Entry-->
</div>
  
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
      <!--begin::Card-->
      <div class="card card-custom">
        <div class="card-header flex-wrap border-0 pt-6 pb-0">
          <div class="card-title">
            <h3 class="card-label">Top Tháng</h3>
          </div>
          <div class="card-toolbar">
          </div>
        </div>
        <div class="card-body">
          <!--begin::Search Form-->
          <div class="mb-7">
            <div class="row align-items-center">
              <div class="col-lg-9 col-xl-8">
                <div class="row align-items-center">
                  <div class="col-md-4 my-2 my-md-0">
                    <div class="input-icon">
                      <input type="text" class="form-control" placeholder="Search..." id="kt_datatable_search_query" />
                      <span>
                        <i class="flaticon2-search-1 text-muted"></i>
                      </span>
                    </div>
                  </div>
                  
                </div>
              </div>
              <div class="col-lg-3 col-xl-4 mt-5 mt-lg-0">
                <a href="#kt_his" class="btn btn-light-primary px-6 font-weight-bold">Search</a>
              </div>
            </div>
          </div>
          <!--end::Search Form-->
          <!--begin: Datatable-->
          <div class="datatable datatable-bordered datatable-head-custom" id="kt_datatable"></div>
          <!--end: Datatable-->
        </div>
      </div>
      <!--end::Card-->
    </div>
    <!--end::Container-->
  </div>
  <!--end::Entry-->
</div></div>
</div>
<script src="/assets/js/pages/crud/ktdatatable/base/thongke.js?v=<?=rand(1,99993219)?>"></script>

<script>
    
var _demo2 = function () {
		const apexChart = "#chart_2";
		var options = {
			series: [{
                name: 'Tiền Nhận',
                <?php
                    $totalDay1 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE day(created_at) = day(NOW()) AND month(created_at) = month(NOW()) AND year(created_at) = year(NOW()) AND status_momo = '999' AND `user_id` = '".$accounts['username']."' ") ?: 0;
                    $totalDay2 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getStartNgay(1)."'  AND `time_tran` <= '".getFinishNgay(1)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay3 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getStartNgay(2)."'  AND `time_tran` <= '".getFinishNgay(2)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay4 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getStartNgay(3)."'  AND `time_tran` <= '".getFinishNgay(3)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay5 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE  `time_tran` >= '".getStartNgay(4)."'  AND `time_tran` <= '".getFinishNgay(4)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay6 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getStartNgay(5)."'  AND `time_tran` <= '".getFinishNgay(5)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay7 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getStartNgay(6)."'  AND `time_tran` <= '".getFinishNgay(6)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;

                ?>
                data: [<?=$totalDay7?>, <?=$totalDay6?>, <?=$totalDay5?>, <?=$totalDay4?>, <?=$totalDay3?>, <?=$totalDay2?> , <?=$totalDay1?>]
            },{
                name: 'Tiền Trả',
                <?php
                    $totalDay11 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE day(created_at) = day(NOW()) AND month(created_at) = month(NOW()) AND year(created_at) = year(NOW()) AND status_momo = '999' AND `user_id` = '".$accounts['username']."' ") ?: 0;
                    $totalDay22 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getStartNgay(1)."'  AND `time_tran` <= '".getFinishNgay(1)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay33 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getStartNgay(2)."'  AND `time_tran` <= '".getFinishNgay(2)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay44 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getStartNgay(3)."'  AND `time_tran` <= '".getFinishNgay(3)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay55 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE  `time_tran` >= '".getStartNgay(4)."'  AND `time_tran` <= '".getFinishNgay(4)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay66 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getStartNgay(5)."'  AND `time_tran` <= '".getFinishNgay(5)."' AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay77 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getStartNgay(6)."'  AND `time_tran` <= '".getFinishNgay(6)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;

                ?>
                data: [<?=$totalDay77?>, <?=$totalDay66?>, <?=$totalDay55?>, <?=$totalDay44?>, <?=$totalDay33?>, <?=$totalDay22?> , <?=$totalDay11?>]
            },{
                name: 'Tiền Lãi',
                
                
                data: [<?=$totalDay7-$totalDay77?>, <?=$totalDay6-$totalDay66?>, <?=$totalDay5-$totalDay55?>, <?=$totalDay4-$totalDay44?>, <?=$totalDay3-$totalDay33?>, <?=$totalDay2-$totalDay22?> , <?=$totalDay1-$totalDay11?>]
            }, {
                name: 'Tiền Gửi',
                <?php
                    $totalDay1 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE day(date_time) = day(NOW()) AND month(date_time) = month(NOW()) AND year(date_time) = year(NOW())  AND status = 'success'  AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay2 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getStartNgay(1)."'  AND `time` <= '".getFinishNgay(1)."'  AND status = 'success' AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay3 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getStartNgay(2)."'  AND `time` <= '".getFinishNgay(2)."'  AND status = 'success' AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay4 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getStartNgay(3)."'  AND `time` <= '".getFinishNgay(3)."'   AND status = 'success' AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay5 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getStartNgay(4)."'  AND `time` <= '".getFinishNgay(4)."'   AND status = 'success' AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay6 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getStartNgay(5)."'  AND `time` <= '".getFinishNgay(5)."'   AND status = 'success' AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalDay7 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getStartNgay(6)."'  AND `time` <= '".getFinishNgay(6)."'   AND status = 'success' AND `type` = '0' AND `user_id` = '".$accounts['username']."'") ?: 0;
                ?>
                data: [<?=($totalDay7)?>, <?=($totalDay6)?>, <?=($totalDay5)?>, <?=($totalDay4)?>, <?=($totalDay3)?>, <?=($totalDay2)?>, <?=($totalDay1)?>]
            }],
			chart: {
				height: 350,
				type: 'area'
			},
			dataLabels: {
				enabled: false
			},
			stroke: {
				curve: 'smooth'
			},
			xaxis: {
				categories: ['<?=date("Y-m-d", strtotime("-6 day"))?>', '<?=date("Y-m-d", strtotime("-5 day"))?>', '<?=date("Y-m-d", strtotime("-4 day"))?>', '<?=date("Y-m-d", strtotime("-3 day"))?>', '<?=date("Y-m-d", strtotime("-2 day"))?>', '<?=date("Y-m-d", strtotime("-1 day"))?>','<?=date("Y-m-d", strtotime("today"))?>']
			},
			colors: [primary , info , danger, warning ]
		};

		var chart = new ApexCharts(document.querySelector(apexChart), options);
		chart.render();
	}
    var _demo3 = function () {
		const apexChart = "#chart_3";
		var options = {
			series: [{
                name: 'Tiền Nhận',
                <?php
                    $totalMonth1 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getNgayDauThang(0)."'  AND `time_tran` <= '".getNgayCuoiThang(0)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalMonth2 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getNgayDauThang(1)."'  AND `time_tran` <= '".getNgayCuoiThang(1)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalMonth3 = $db->fetch_row("SELECT SUM(amount) FROM momo_history WHERE `time_tran` >= '".getNgayDauThang(2)."'  AND `time_tran` <= '".getNgayCuoiThang(2)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    
                ?>
                data: [<?=$totalMonth3?>, <?=$totalMonth2?> , <?=$totalMonth1?>]
            },{
                name: 'Tiền Trả',
                <?php
                    $totalMonth11 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getNgayDauThang(0)."'  AND `time_tran` <= '".getNgayCuoiThang(0)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalMonth22 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getNgayDauThang(1)."'  AND `time_tran` <= '".getNgayCuoiThang(1)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalMonth33 = $db->fetch_row("SELECT SUM(amount_paid) FROM momo_history WHERE `time_tran` >= '".getNgayDauThang(2)."'  AND `time_tran` <= '".getNgayCuoiThang(2)."'  AND status_momo = '999' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    
                ?>
                data: [<?=$totalMonth33?>, <?=$totalMonth22?> , <?=$totalMonth11?>]
            },{
                name: 'Tiền Lãi',
                data: [<?=$totalMonth3-$totalMonth33?>, <?=$totalMonth2-$totalMonth22?> , <?=$totalMonth1-$totalMonth11?>]
            }, {
                name: 'Tiền Gửi',
                <?php
                    $totalMonth1 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getNgayDauThang(0)."'  AND `time` <= '".getNgayCuoiThang(0)."' AND `type` = '0' AND status = 'success' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalMonth2 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getNgayDauThang(1) . "'  AND `time` <= '".getNgayCuoiThang(1)."' AND `type` = '0' AND status = 'success' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    $totalMonth3 = $db->fetch_row("SELECT SUM(amount) FROM send WHERE `time` >= '".getNgayDauThang(2)."'  AND `time` <= '".getNgayCuoiThang(2)."' AND `type` = '0' AND status = 'success' AND `user_id` = '".$accounts['username']."'") ?: 0;
                    ?>
                data: [ <?=($totalMonth3)?>, <?=($totalMonth2)?>, <?=($totalMonth1)?>]
            }],
			chart: {
				height: 350,
				type: 'area'
			},
			dataLabels: {
				enabled: false
			},
			stroke: {
				curve: 'smooth'
			},
			xaxis: {
                categories: ['<?=date("Y-m", strtotime("-2 month"))?>', '<?=date("Y-m", strtotime("-1 month"))?>', '<?=$month?>-<?=$year?>'],
			},
			colors: [primary , info , danger, warning ]
		};

		var chart = new ApexCharts(document.querySelector(apexChart), options);
		chart.render();
	}
    function number_format(num, decimals = ",") {
        return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1' + decimals);
    }
</script>
<script src="/assets/js/pages/features/charts/apexcharts49d8.js?v=<?=rand()?>"></script>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/view/foot.php');
?>
