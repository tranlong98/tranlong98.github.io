<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$settings = $db->fetch_assoc("SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1", 1);
$order = $settings['sapxep'];
$soluong = $settings['soluong'];

if($order == 1){
   
    $result_phone = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `user_id` = '".$settings['username']."' AND `status` = '1' ORDER BY rand() LIMIT $soluong",0);
    $i = 0;
    foreach ($result_phone as $key3 => $value){
                             $i++;
    $game = json_decode($value['game'],true)[0];
     $results[] = array(
        'sdt' => substr($value['partnerId'],0,-5). '***', 
        'tiencuoc' => $value['amount'], 
        'trochoi' => $game['name'], 
        'tiennhan' => $game['amount_win'], 
        'noidung' => $value['comment'], 
        'updated_at' => date("d-m-Y H:i:s",time() + $i * 1.5));   
 }
 echo json_encode($results);
}elseif($order == 0){
    
    $result_phone = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `user_id` = '".$settings['username']."' AND `status` = '1' ORDER BY `id` DESC LIMIT $soluong",0);
    $i = 0;
    foreach ($result_phone as $key3 => $value){
    $i++;
    $date = date("d-m-Y H:i:s",$value['updated_at']);
    $game = json_decode($value['game'],true)[0];
    
     $results[] = array(
        'sdt' => substr($value['partnerId'],0,-5). '***', 
        'tiencuoc' => $value['amount'], 
        'trochoi' => $game['name'], 
        'tiennhan' => $game['amount_win'], 
        'noidung' => $value['comment'], 
        'updated_at' => $value['time_tran_date']);   
 } 
   echo json_encode($results);  
}
   