<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
     $result_phone = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `user_id` = '".$settings['username']."' AND `status` = 'success' AND `today` < `limit_day` AND `month` < `limit_month` ORDER BY RAND() LIMIT 5",0);
                       $i = 0;
                        foreach ($result_phone as $key3 => $value){
                             $i++; 
                           
                            $results[] = array(
                                'sdt' => $value['phone'], 
                                'today' => number_format($value['today']),
                                'limit_day' => $value['limit_day'], 
                                'limit_month' => $value['limit_month'], 
                                'today_gd' => $value['today_gd'], 
                                'ghbank' => $value['ghbank']);   
                         }
                           echo json_encode($results);