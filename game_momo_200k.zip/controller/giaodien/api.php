<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
    $tran_id = $db->real_escape_string(junoo_boc(POST("tran_id")));
    if(!$tran_id) {
        die(json_encode(array(
            "status" => "99",
            "msg" => "Vui lòng nhập mã giao dịch"
        )));
    }
    $result = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id_tran` = '".$tran_id."'  ORDER BY `id` DESC ",1);
    $ls_sdt = $result['partnerId'];
    $ls_sotien = $result['amount'];
    $ls_noidung = $result['comment'];
    $ls_ketqua = $result['status'];
    $ls_tiennhan = $result['amount_paid'];
    //$ls_trangthai = $result['status'];
    $ls_thoigian = $result['created_at'];
    $ls_loaitrochoi = $result['game'];

    $datas = json_decode($ls_loaitrochoi);
    foreach($datas as $tran) {
    $name = $tran->name;
    $text = $tran->text;
    }

    if(!$result['id']) {
        die(json_encode(array(
            "status" => "404",
            "msg" => "Không tồn tại mã giao dịch này "
        )));
    }
    
    
    die(json_encode(array(
            "status" => "200",
            "ls_magd" => "$tran_id",
            "ls_sdt" => "$ls_sdt",
            "ls_sotien" => "$ls_sotien",
            "ls_noidung" => "$ls_noidung",
            "ls_loaitrochoi" => "$name",
            "ls_ketqua" => "$text",
            "ls_tiennhan" => "$ls_tiennhan",
            "ls_trangthai" => "".getStatus($ls_ketqua),
            "ls_thoigian" => "$ls_thoigian",
            "msg" => "TranID: ".$tran_id.", trạng thái: ".getStatus($result['status'])
    )));
