<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
    if(!is_client()){
        die(json_encode(array("status" => "error","msg" => "Vui lòng đăng nhập trước nhé.")));
    }
        $id = $db->real_escape_string(junoo_boc(GET("id")));
        $result = $db->fetch_assoc("SELECT * FROM `game_option` WHERE `username` = '".$accounts['username']."' AND `game_id` = '".$id."' ORDER BY `id` DESC ",0);
        $i = 1;
        $data = array();
        foreach($result as $key => $row) {
            $data[] = $row;
            $i++;
        }
        echo json_encode(($data));
    
    