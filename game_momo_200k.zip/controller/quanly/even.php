<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
    if(!is_client()){
        die(json_encode(array("status" => "error","msg" => "Vui lòng đăng nhập trước nhé.")));
    }
        $result = $db->fetch_assoc("SELECT * FROM `even` WHERE `username` = '".$accounts['username']."' ORDER BY `id` DESC ",0);
        $i = 1;
        $data = array();
        foreach($result as $key => $row) {
            $data[] = [
                'RecordID' => $row['id'],
                'ID' => $row['id'],
                'game' => $row['game'],
                'momotra' => $row['momotra'],
                'trangthai' => $row['trangthai'],
                'Actions' => '',
            ];
            $i++;
        }
        echo json_encode(($data));
    
    