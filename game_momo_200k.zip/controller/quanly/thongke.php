<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
    if(!is_client()){
        die(json_encode(array("status" => "error","msg" => "Vui lòng đăng nhập trước nhé.")));
    }
    if(GET("type") == 'month') {
        $ngaydaucuathang = strtotime(date('01-m-Y'));
        $ngaycuoicuathang = strtotime('23:59:59 '.date('t-m-Y'));
        $where = "AND `time_tran` >= '".$ngaydaucuathang."'  AND `time_tran` <= '".$ngaycuoicuathang."'  AND status_momo = '999'";
        $result_momo_history = $db->fetch_assoc("SELECT SUM(amount),SUM(amount_paid), partnerName, partnerId FROM `momo_history` WHERE  `user_id` = '".$accounts['username']."' $where GROUP BY `partnerId` ORDER BY SUM(amount) DESC",0);        
        $i = 1;
        $data = array();
        foreach($result_momo_history as $key => $row) {
            $total_win = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' AND `status` = '1'   $where ");
            $total_lose = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' AND `status` != '1'   $where ");
            $result_amount_lose = $db->fetch_assoc("SELECT SUM(amount) FROM `momo_history` WHERE `partnerId` = '".$row['partnerId']."' AND `status` != '1'   $where",1);        
            $total = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' $where ");
            $data[] = [
                'RecordID' => $i,
                'partnerName' => $row['partnerName'],
                'partnerId' => $row['partnerId'],
                'amount' => number_format($row['SUM(amount)'])."<sup>VNĐ</sup>",
                'amount_lose' => number_format($result_amount_lose['SUM(amount)'])."<sup>VNĐ</sup>",
                'amount_paid' => number_format($row['SUM(amount_paid)'])."<sup>VNĐ</sup>",
                'win' => number_format($total_win)."<sup>Lần</sup>",
                'total' => number_format($total)."<sup>Lần</sup>",
                'lose' => number_format($total_lose)."<sup>Lần</sup>",
            ];
            $i++;
        }
        echo json_encode(($data));
    }elseif(GET("type") == 'week') {
        $tuan = getTuan();
        $ngaydaucuatuan = getTimeStartTuan($tuan);
        $ngaycuoicuatuan = getTimeEndTuan($tuan);
        $where = "AND `time_tran` >= '".$ngaydaucuatuan."'  AND `time_tran` <= '".$ngaycuoicuatuan."'  AND status_momo = '999'";
        $result_momo_history = $db->fetch_assoc("SELECT SUM(amount),SUM(amount_paid), partnerName, partnerId FROM `momo_history` WHERE  `user_id` = '".$accounts['username']."' $where GROUP BY `partnerId` ORDER BY SUM(amount) DESC",0);        
        $i = 1;
        $data = array();
        foreach($result_momo_history as $key => $row) {
            $total_win = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' AND `status` = '1'   $where ");
            $total_lose = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' AND `status` != '1'   $where ");
            $result_amount_lose = $db->fetch_assoc("SELECT SUM(amount) FROM `momo_history` WHERE `partnerId` = '".$row['partnerId']."' AND `status` != '1'   $where",1);        
            $total = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' $where ");
            $data[] = [
                'RecordID' => $i,
                'partnerName' => $row['partnerName'],
                'partnerId' => $row['partnerId'],
                'amount' => number_format($row['SUM(amount)'])."<sup>VNĐ</sup>",
                'amount_lose' => number_format($result_amount_lose['SUM(amount)'])."<sup>VNĐ</sup>",
                'amount_paid' => number_format($row['SUM(amount_paid)'])."<sup>VNĐ</sup>",
                'win' => number_format($total_win)."<sup>Lần</sup>",
                'total' => number_format($total)."<sup>Lần</sup>",
                'lose' => number_format($total_lose)."<sup>Lần</sup>",
            ];
            $i++;
        }
        echo json_encode(($data));
    }else{
        
        $where = "AND day(created_at) = day(NOW()) AND month(created_at) = month(NOW()) AND year(created_at) = year(NOW())  AND status_momo = '999'";
        $result_momo_history = $db->fetch_assoc("SELECT SUM(amount),SUM(amount_paid), partnerName, partnerId FROM `momo_history` WHERE  `user_id` = '".$accounts['username']."' $where GROUP BY `partnerId` ORDER BY SUM(amount) DESC",0);        
        $i = 1;
        $data = array();
        foreach($result_momo_history as $key => $row) {
            $total_win = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' AND `status` = '1'   $where ");
            $total_lose = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' AND `status` != '1'   $where ");
            $result_amount_lose = $db->fetch_assoc("SELECT SUM(amount) FROM `momo_history` WHERE `partnerId` = '".$row['partnerId']."' AND `status` != '1'   $where",1);        
            $total = $db->num_rows("SELECT * FROM `momo_history` WHERE  `partnerId` = '".$row['partnerId']."' $where ");
            $data[] = [
                'RecordID' => $i,
                'partnerName' => $row['partnerName'],
                'partnerId' => $row['partnerId'],
                'amount' => number_format($row['SUM(amount)'])."<sup>VNĐ</sup>",
                'amount_lose' => number_format($result_amount_lose['SUM(amount)'])."<sup>VNĐ</sup>",
                'amount_paid' => number_format($row['SUM(amount_paid)'])."<sup>VNĐ</sup>",
                'win' => number_format($total_win)."<sup>Lần</sup>",
                'total' => number_format($total)."<sup>Lần</sup>",
                'lose' => number_format($total_lose)."<sup>Lần</sup>",
            ];
            $i++;
        }
        echo json_encode(($data));
    }
    