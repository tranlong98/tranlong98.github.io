<?php
    include 'momo.php'; // database & function
         $getdl2 = $db->fetch_assoc("SELECT * FROM `even` WHERE  `id` = '2'",1);  
           $moc1 = $getdl2['moc1'];
           $thuong1 = $getdl2['thuong1'];
           $moc2 = $getdl2['moc2'];
           $thuong2 = $getdl2['thuong2'];
           $moc3 = $getdl2['moc3'];
           $thuong3 = $getdl2['thuong3'];
           $moc4 = $getdl2['moc4'];
           $thuong4 = $getdl2['thuong4'];
           $moc5 = $getdl2['moc4'];
           $thuong5 = $getdl2['thuong5'];
           $momotra = $getdl2['momotra'];
if(isset($_POST['PhoneChoia'])){
$magiaodich = htmlspecialchars($_POST['PhoneChoia']);
$now = date("Y-m-d");
$demluot = $db->num_rows("SELECT * FROM `momo_history` WHERE `id_tran` = '$magiaodich' AND `created_at` >= '$now 00:00:00'");
$demluot2 = $db->num_rows("SELECT * FROM `momo_history` WHERE `partnerId` = '$magiaodich' AND `created_at` >= '$now 00:00:00'");
if(empty($demluot) && empty($demluot2)){
echo json_encode(array('ketqua' => "Mã giao dịch này hoặc số điện thoại này không tồn tại trên lịch sử chơi game vào ngày hôm nay  !")); 
exit();
}else{
if($demluot > 0){    
$getdl2sdtne = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE  `id_tran` = '$magiaodich'",1);  
           $sdtchoi = $getdl2sdtne['partnerId'];
}else{
$sdtchoi = $magiaodich;    
}           

$dem1 = $db->num_rows("SELECT * FROM `send` WHERE  `comment` = 'THUONGREF1$sdtchoi' AND `status` = 'success'  AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 1 chưa
$dem2 = $db->num_rows("SELECT * FROM `send` WHERE  `comment` = 'THUONGREF2$sdtchoi' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 2 chưa
$dem3 = $db->num_rows("SELECT * FROM `send` WHERE  `comment` = 'THUONGREF3$sdtchoi' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 3 chưa
$dem4 = $db->num_rows("SELECT * FROM `send` WHERE  `comment` = 'THUONGREF4$sdtchoi' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 4 chưa

         $accounts['username'] = 'admin';
        $getdl = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `user_id` = '".$accounts['username']."' AND `status` = 'success' AND `phone` = '$momotra'",1);  
        $from = $getdl['phone'];
        
        if(!$sdtchoi || !$from){
        echo json_encode(array('ketqua' => "Số điện thoại chơi không tồn tại hoặc lỗi hệ thống không có tài khoản MoMo trả thưởng  !"));
        exit();
        }
        $from = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$from."' AND `user_id` = '".$accounts['username']."' AND `phone` = '$momotra' LIMIT 1 ",1);
        if(!$from['phone']) {
        echo json_encode(array('ketqua' => "Momo Không tồn tại!"));  
        exit();
        }
        $result = $momo->LoadData($from['phone'],$accounts['username'])->CheckName($sdtchoi);
        $ten = $result['name']; // Lấy được tên của người nhận
    
    
$cashchoi = $db->fetch_row("SELECT SUM(amount) FROM `momo_history` WHERE `partnerId` = '$sdtchoi' AND `created_at` >= '$now 00:00:00'"); // tính tổng hôm nay chơi đc bao nhiêu rồi nè
$cashchoi2 = number_format($cashchoi); // làm màu cho đẹp
if($cashchoi < $moc1){
echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten đã chơi $cashchoi2 VNĐ, hãy chơi tiếp để nhận thêm phần quà giá trị !"));    
}elseif($cashchoi >= $moc1 && $dem1 == 0){
 echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 1, hãy nhập SĐT bạn vào để nhận thưởng !"));      
}elseif($cashchoi < $moc2){
echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 2, hãy chơi thêm để nhận thêm phần quà giá trị !"));    
}elseif($cashchoi >= $moc2 && $dem2 == 0){
 echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 2, hãy nhập SĐT bạn vào để nhận thưởng !"));     
}elseif($cashchoi < $moc3){
echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 3, hãy chơi thêm để nhận thêm phần quà giá trị !"));    
}elseif($cashchoi >= $moc3 && $dem3 == 0){
 echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 3, hãy nhập SĐT bạn vào để nhận thưởng !"));     
}elseif($cashchoi < $moc4){
echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 4, hãy chơi thêm để nhận thêm phần quà giá trị !"));    
}elseif($cashchoi >= $moc4 && $dem4 == 0){
 echo json_encode(array('ketqua' => "Chúc mừng người bạn giới thiệu: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 4, hãy nhập SĐT bạn vào để nhận thưởng !"));     
}else{
echo json_encode(array('ketqua' => "Bạn đã nhận hết thưởng hôm nay rồi, quay lại vào ngày mai nhé, nhận thưởng nữa mình còn cái nịt mất !"));      
}
        
    }    
}else{
echo json_encode(array('ketqua' => "còn cái nịt mất !")); 
    
}
?>