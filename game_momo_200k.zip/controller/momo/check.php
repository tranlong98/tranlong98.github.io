<?php
    include 'momo.php'; 
    $getdl2 = $db->fetch_assoc("SELECT * FROM `even` WHERE  `id` = '1' AND `trangthai` = 'run'",1);  
           $moc1 = $getdl2['moc1'];
           $thuong1 = $getdl2['thuong1'];
           $moc2 = $getdl2['moc2'];
           $thuong2 = $getdl2['thuong2'];
           $moc3 = $getdl2['moc3'];
           $thuong3 = $getdl2['thuong3'];
           $moc4 = $getdl2['moc4'];
           $thuong4 = $getdl2['thuong4'];
           $moc5 = $getdl2['moc5'];
           $thuong5 = $getdl2['thuong5'];
           $momotra = $getdl2['momotra'];
           
if(isset($_POST['PhoneChoi'])){
$sdtchoi = htmlspecialchars($_POST['PhoneChoi']);
$comment1 = 'THUONGMOC1';
$comment2 = 'THUONGMOC2';
$comment3 = 'THUONGMOC3';
$comment4 = 'THUONGMOC4';
$comment5 = 'THUONGMOC5';

$now = date("Y-m-d");
$lanchoi = $db->num_rows("SELECT * FROM `momo_history` WHERE `partnerId` = '$sdtchoi' AND `created_at` >= '$now 00:00:00'"); // check xem sdt chơi lần nào chưa nè
$dem1 = $db->num_rows("SELECT * FROM `send` WHERE `partnerId` = '$sdtchoi' AND `comment` = 'THUONGMOC1' AND `status` = 'success'  AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 1 chưa
$dem2 = $db->num_rows("SELECT * FROM `send` WHERE `partnerId` = '$sdtchoi' AND `comment` = 'THUONGMOC2' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 2 chưa
$dem3 = $db->num_rows("SELECT * FROM `send` WHERE `partnerId` = '$sdtchoi' AND `comment` = 'THUONGMOC3' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 3 chưa
$dem4 = $db->num_rows("SELECT * FROM `send` WHERE `partnerId` = '$sdtchoi' AND `comment` = 'THUONGMOC4' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 4 chưa
$dem5 = $db->num_rows("SELECT * FROM `send` WHERE `partnerId` = '$sdtchoi' AND `comment` = 'THUONGMOC5' AND `status` = 'success' AND `date_time` >= '$now 00:00:00'"); // check xem đã trả thưởng mốc 5 chưa
if($lanchoi == 0){
echo json_encode(array('ketqua' => "Số điện thoại này hôm nay chưa chơi trên hệ thống !
Chú ý : Phải nhập sdt là số cũ vd: 082xxx -> 0129xxx , 03xxx -> 016...  !"));    
}else{
         $accounts['username'] = 'admin';
        $getdl = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `user_id` = '".$accounts['username']."' AND `status` = 'success' AND `phone` = '$momotra'",1);  
        $from = $getdl['phone'];
        
        if(!$sdtchoi || !$from){
        echo json_encode(array('ketqua' => "Số điện thoại chơi không tồn tại hoặc lỗi hệ thống không có tài khoản MoMo trả thưởng !"));
        exit();
        }
        $from = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '".$from."' AND `user_id` = '".$accounts['username']."' AND `phone` = '$momotra' LIMIT 1 ",1);
        if(!$from['phone']) {
        echo json_encode(array('ketqua' => "Momo Không tồn tại!"));  
        exit();
        }
        $result = $momo->LoadData($from['phone'],$accounts['username'])->CheckName($sdtchoi);
        $ten = $result['name']; // Lấy được tên của người nhận

    
$cashchoi = $db->fetch_row("SELECT SUM(amount) FROM `momo_history` WHERE `partnerId` = '$sdtchoi' AND `created_at` >= '$now 00:00:00'"); // tính tổng hôm nay chơi đc bao nhiêu rồi nè
$cashchoi2 = number_format($cashchoi); // làm màu cho đẹp

if($cashchoi < $moc1){
echo json_encode(array('ketqua' => "Bạn đã chơi $cashchoi2 VNĐ, hãy chơi tiếp để nhận mốc !"));    
}elseif($cashchoi >= $moc1 && $dem1 == 0){
        
        $result = $momo->LoadData($from['phone'],$accounts['username'])->SendMoney($sdtchoi,$thuong1,$comment1);
        $data_send = $result['full'];
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '".$result['tranDList']['ID']."', '".$result['tranDList']['tranId']."', '".$result['tranDList']['partnerId']."', '".$result['tranDList']['partnerName']."', '".$result['tranDList']['amount']."', '".$result['tranDList']['comment']."', '".time()."', '".$accounts['username']."', '".$result['status']."', '".$result['message']."', '".$data_send."','".$result['tranDList']['balance']."','".$result['tranDList']['ownerNumber']."','".$result['tranDList']['ownerName']."','0')");
  if($result['status'] == 'success'){      
    echo json_encode(array('ketqua' => "Chúc mừng bạn: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 1, hãy chơi thêm để nhận thêm phần quà giá trị !"));     // thưởng & ghi lại lịch sử
            }else{
    echo json_encode(array('ketqua' => "Trả thưởng nhiệm vụ mốc 1 thất bại,  xin vui lòng liên hệ Admin !"));                
            }
}elseif($cashchoi < $moc2){
echo json_encode(array('ketqua' => "Xin lỗi bạn đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 2, hãy chơi tiếp để nhận mốc !"));    
}elseif($cashchoi >= $moc2 && $dem2 == 0){
        $result = $momo->LoadData($from['phone'],$accounts['username'])->SendMoney($sdtchoi,$thuong2,$comment2);
        $data_send = $result['full'];
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '".$result['tranDList']['ID']."', '".$result['tranDList']['tranId']."', '".$result['tranDList']['partnerId']."', '".$result['tranDList']['partnerName']."', '".$result['tranDList']['amount']."', '".$result['tranDList']['comment']."', '".time()."', '".$accounts['username']."', '".$result['status']."', '".$result['message']."', '".$data_send."','".$result['tranDList']['balance']."','".$result['tranDList']['ownerNumber']."','".$result['tranDList']['ownerName']."','0')");
  if($result['status'] == 'success'){      
    echo json_encode(array('ketqua' => "Chúc mừng bạn: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 2, hãy chơi thêm để nhận thêm phần quà giá trị !"));     // thưởng & ghi lại lịch sử
            }else{
    echo json_encode(array('ketqua' => "Trả thưởng mốc 2 thất bại, xin vui lòng liên hệ Admin !"));                
            }
}elseif($cashchoi < $moc3){
echo json_encode(array('ketqua' => "Xin lỗi bạn đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 3, hãy chơi tiếp để nhận mốc !"));    
}elseif($cashchoi >= $moc3 && $dem3 == 0){
        $result = $momo->LoadData($from['phone'],$accounts['username'])->SendMoney($sdtchoi,$thuong3,$comment3);
        $data_send = $result['full'];
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '".$result['tranDList']['ID']."', '".$result['tranDList']['tranId']."', '".$result['tranDList']['partnerId']."', '".$result['tranDList']['partnerName']."', '".$result['tranDList']['amount']."', '".$result['tranDList']['comment']."', '".time()."', '".$accounts['username']."', '".$result['status']."', '".$result['message']."', '".$data_send."','".$result['tranDList']['balance']."','".$result['tranDList']['ownerNumber']."','".$result['tranDList']['ownerName']."','0')");
  if($result['status'] == 'success'){      
    echo json_encode(array('ketqua' => "Chúc mừng bạn: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 3, hãy chơi thêm để nhận thêm phần quà giá trị !"));     // thưởng & ghi lại lịch sử
            }else{
    echo json_encode(array('ketqua' => "Trả thưởng mốc 3 thất bại, xin vui lòng liên hệ Admin !"));                
            }
}elseif($cashchoi < $moc4){
echo json_encode(array('ketqua' => "Xin lỗi bạn đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 4, hãy chơi tiếp để nhận mốc !"));    
}elseif($cashchoi >= $moc4 && $dem4 == 0){
        $result = $momo->LoadData($from['phone'],$accounts['username'])->SendMoney($sdtchoi,$thuong4,$comment4);
        $data_send = $result['full'];
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '".$result['tranDList']['ID']."', '".$result['tranDList']['tranId']."', '".$result['tranDList']['partnerId']."', '".$result['tranDList']['partnerName']."', '".$result['tranDList']['amount']."', '".$result['tranDList']['comment']."', '".time()."', '".$accounts['username']."', '".$result['status']."', '".$result['message']."', '".$data_send."','".$result['tranDList']['balance']."','".$result['tranDList']['ownerNumber']."','".$result['tranDList']['ownerName']."','0')");
  if($result['status'] == 'success'){      
    echo json_encode(array('ketqua' => "Chúc mừng bạn: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 4, hãy chơi thêm để nhận thêm phần quà giá trị !"));     // thưởng & ghi lại lịch sử
            }else{
    echo json_encode(array('ketqua' => "Trả thưởng mốc 4 thất bại, xin vui lòng liên hệ Admin !"));                
            }
}elseif($cashchoi < $moc5){
echo json_encode(array('ketqua' => "Xin lỗi bạn đã chơi $cashchoi2 VNĐ, sắp được thưởng mốc 5, hãy chơi tiếp để nhận mốc !"));
}elseif($cashchoi >= $moc5 && $dem5 == 0){
        $result = $momo->LoadData($from['phone'],$accounts['username'])->SendMoney($sdtchoi,$thuong5,$comment5);
        $data_send = $result['full'];
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '".$result['tranDList']['ID']."', '".$result['tranDList']['tranId']."', '".$result['tranDList']['partnerId']."', '".$result['tranDList']['partnerName']."', '".$result['tranDList']['amount']."', '".$result['tranDList']['comment']."', '".time()."', '".$accounts['username']."', '".$result['status']."', '".$result['message']."', '".$data_send."','".$result['tranDList']['balance']."','".$result['tranDList']['ownerNumber']."','".$result['tranDList']['ownerName']."','0')");
  if($result['status'] == 'success'){      
    echo json_encode(array('ketqua' => "Chúc mừng bạn: $ten  đã chơi $cashchoi2 VNĐ, nhận được thưởng mốc 5, hãy chơi thêm để nhận thêm phần quà giá trị !"));     // thưởng & ghi lại lịch sử
            }else{
    echo json_encode(array('ketqua' => "Trả thưởng mốc 5 thất bại, xin vui lòng liên hệ Admin !"));                
            }
}else{
echo json_encode(array('ketqua' => "Bạn đã nhận hết thưởng hôm nay rồi, quay lại vào ngày mai nhé, nhận thưởng nữa mình còn cái nịt mất !"));      
}
    }
}else{
echo json_encode(array('ketqua' => "còn cái nịt mất !"));    
}
?>