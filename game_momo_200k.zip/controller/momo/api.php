<?php
include "momo.php";
$act = GET("act");
$type = GET("type") ? : 0;
if ($act == "getToken")
{
    $phone = $db->real_escape_string(junoo_boc(POST("phone")));
    $user_id = $db->real_escape_string(junoo_boc(POST("user_id")));
    $api_key = $db->real_escape_string(POST("api_key"));
    if ($phone)
    {
        $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '" . $phone . "' AND `user_id` = '" . $user_id . "' ORDER BY `id` ASC LIMIT 1", 1);
        if (!$result["phone"])
        {
            die(json_encode(["status" => "error", "code" => - 99, "message" => "Không tồn tại tài khoản momo", ]));
        }
        $result_user = $db->fetch_assoc("SELECT * FROM `accounts` WHERE `username` = '" . $user_id . "' ORDER BY `id` ASC LIMIT 1", 1);
        if (!$result_user["api_key"] || $result_user["api_key"] != $api_key)
        {
            die(json_encode(["status" => "error", "code" => - 100, "message" => "API KEY không hợp lệ hoặc chưa được kích hoạt", ]));
        }
        echo json_encode($result1);
    }
    elseif ($type == 9)
    {
        $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `status` = 'success' ORDER BY `id` ASC ", 0);
        foreach ($result as $key => $row)
        {
            if (!$row["Name"] || $row["Name"] == "")
            {
                $result12 = $momo->LoadData($row["phone"], $row["user_id"])->CheckName($row["phone"]);
                $db->query("UPDATE `cron_momo` SET `Name` = '" . $result12["name"] . "' WHERE `phone` = '" . $row["phone"] . "' ");
            }
            $result1 = $momo->LoadData($row["phone"], $row["user_id"])->LoginTimeSetup();

            echo "<pre>";
            print_r($result1);
            echo "<pre>";
        }
        $result1 = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `status` = 'error' AND `try` <= '3' ORDER BY `id` ASC ", 0);
        foreach ($result1 as $key => $row)
        {
            if (!$row["Name"] || $row["Name"] == "")
            {
                $result12 = $momo->LoadData($row["phone"], $row["user_id"])->CheckName($row["phone"]);
                $db->query("UPDATE `cron_momo` SET `Name` = '" . $result12["name"] . "' WHERE `phone` = '" . $row["phone"] . "' ");
            }
            $result12 = $momo->LoadData($row["phone"], $row["user_id"])->LoginTimeSetup();

            echo "<pre>";
            print_r($result12);
            echo "<pre>";
        }
    }
    else
    {
        die(json_encode(["status" => "error", "code" => - 99, "message" => "Không tồn tại tài khoản momo", ]));
    }
}
elseif ($act == 'paidError')
{
    if ($settings["auto_paid"] == 1)
    {

        $result_tran = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE  `user_id` = '" . $settings["username"] . "'  AND `try` <= '3' AND `status` = '2' AND `amount_paid` = '0' ORDER BY `id` LIMIT 10", 0);
        foreach ($result_tran as $key => $transaction)
        {
            $game = json_decode($transaction["game"],true);
            $amount_win = $game[0]['amount_win'];
            if (!$amount_win)
            {
                $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán lỗi tự động: Lỗi khi lấy số tiền trả cho khách.", ];
                $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                $db->query("UPDATE `momo_history` SET   `status` = '2', `actions` = '" . $insert_actions . "' ,`amount_paid` = '0' WHERE  `user_id` = '" . $transaction["user_id"] . "'  AND `id` = '" . $transaction["id"] . "' ");
                continue;
            }

            $result_withdraw_phone = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `withdraw_status` = '1'  AND `status` = 'success' AND `BALANCE` >= '" . $amount_win . "' AND `month`  + '" . $amount_win . "' <= `limit_month` AND `today` + '" . $amount_win . "' <= `limit_day` AND `user_id` = '" . $transaction["user_id"] . "' ORDER BY RAND() LIMIT 1", 1);
            if (!$result_withdraw_phone["id"])
            {
                $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán lỗi tự động: Không có MOMO để trả.", ];
                $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                $db->query("UPDATE `momo_history` SET   `status` = '2', `actions` = '" . $insert_actions . "' ,`amount_paid` = '0' WHERE  `user_id` = '" . $transaction["user_id"] . "'  AND `id` = '" . $transaction["id"] . "' ");
                continue;
            }
            $comments = $result_withdraw_phone["noidungtra"] . "TTL: " . $transaction["id_tran"];
            $actions = [];
            $actions1 = json_decode($transaction["actions"],true);
            foreach ($actions1 as $key => $value)
            {
                $actions[] = $value;
            }
            $result_pay = $momo->LoadData($result_withdraw_phone["phone"], $result_withdraw_phone["user_id"])->SendMoney($transaction["partnerId"], $amount_win, $comments);
            $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán lỗi tự động: " . $result_pay["message"] . ",SĐT: " . $result_withdraw_phone["phone"] . ",SD: " . number_format($result_pay["tranDList"]["balance"]) . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
            $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`status` = '6' ,`amount_paid` = '" . $amount_win . "' WHERE  `user_id` = '" . $transaction["user_id"] . "'  AND `id` = '" . $transaction["id"] . "' ");
            $data_send = $result_pay["full"];
            
            $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $transaction["user_id"] . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $data_send . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");
            if ($result_pay["status"] != "success")
            {
                $db->query("UPDATE `momo_history` SET   `status` = '2',`amount_paid` = '0' WHERE  `user_id` = '" . $transaction["user_id"] . "'  AND `id` = '" . $transaction["id"] . "' ");
            }
        }
    }
}
elseif ($act == "getHistories")
{
    $hours = POST("hours") ? : 1;
    $phone = $db->real_escape_string(junoo_boc(POST("phone")));
    $user_id = $db->real_escape_string(junoo_boc(POST("user_id")));
    if ($phone)
    {
        $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '" . $phone . "' AND `user_id` = '" . $user_id . "' ORDER BY `id` ASC LIMIT 1", 1);
        if (!$result["phone"])
        {
            die(json_encode(["status" => "error", "code" => - 99, "message" => "Không tồn tại tài khoản momo", ]));
        }
        $history = $momo->LoadData($result["phone"], $result["user_id"])->CheckHisNew($hours);
        echo "<pre>";
        print_r($history);
        echo "<pre>";
    }
    elseif ($type == 43926492)
    {
        $hours = POST("hours") ? : 1;
        $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `status` = 'success' ORDER BY `id` ASC ", 0);
        foreach ($result as $key => $row)
        {
            $history = $momo->LoadData($row["phone"], $row["user_id"])->CheckHisNew($hours);
            echo "<pre>";
            print_r($history);
            echo "<pre>";
            foreach ($history as $contents)
            {
                $contents["partnerName"] = str_replace(array('<',"'",'>','?','/',"\\",'--','eval(','<php'),array('','','','','','','','',''),htmlspecialchars(addslashes(strip_tags($contents["partnerName"]))));
                $transaction = ["time_tran" => $contents["millisecond"], "io" => 1, "tranId" => $contents["tranId"], "comment" => $contents["comment"], "amount" => $contents["amount"], "partnerId" => $contents["patnerID"], "partnerName" => $contents["partnerName"], "ID" => $contents["ID"], ];
                $exists = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id_momo` = '" . $transaction["ID"] . "' LIMIT 1 ", 1);
                $exists1 = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id_tran` = '" . $transaction["tranId"] . "' LIMIT 1 ", 1);
                $checkFile = strpos(file_get_contents("log.txt"),$transaction["tranId"]);
                
                if (!$exists["id"] && !$exists1["id"] && !$checkFile)
                //if (!$exists["id"] && !$exists1["id"])
                {
                    $game = [];
                    $actions = [];
                    $check_game = checkTransasion($transaction["tranId"], $transaction["amount"], $transaction["comment"], $row["user_id"], $transaction["partnerId"]);
                    $game[] = ["name" => $check_game["name"], "id_game" => $check_game["id_game"], "status_game" => $check_game["status_game"], "status" => $check_game["status"], "text" => $check_game["text"], "amount" => $transaction["amount"], "ratio" => $check_game["ratio"], "amount_win" => $check_game["amount_win"], "reciver" => $row["phone"], ];
                    $insert_game = json_encode($game, JSON_UNESCAPED_UNICODE);
                    $actions[] = ["time" => time() , "person" => "Hệ Thống", "text" => "Check đơn: " . $check_game["text"], ];
                    $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                    $insert = $db->query("INSERT INTO `momo_history` ( `user_id`, `phone`, `id_momo`, `id_tran`, `type`, `partnerId`, `partnerName`, `amount`, `comment`, `full_data`, `time_tran`, `time_tran_date`, `status_momo`, `created_at`, `updated_at`, `game`, `actions`, `status`,`amount_paid`,`try`) VALUES ( '" . $row["user_id"] . "', '" . $row["phone"] . "', '" . $transaction["ID"] . "', '" . $transaction["tranId"] . "', '" . $transaction["io"] . "', '" . $transaction["partnerId"] . "', '" . $transaction["partnerName"] . "', '" . $transaction["amount"] . "', '" . $transaction["comment"] . "', '" . json_encode($transaction) . "', '" . floor($contents["millisecond"] / 1000) . "', '" . date("d/m/Y H:i:s", floor($contents["millisecond"] / 1000)) . "', '999', current_timestamp(), current_timestamp() ,'" . $insert_game . "' , '" . $insert_actions . "','" . $check_game["status"] . "','0','0')");

                    $actions = [];
                    if ($check_game["status"] == 1)
                    {
                        $result_tran = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id_tran` = '" . $transaction["tranId"] . "' LIMIT 1", 1);
                        $comments = $row["noidungtra"] . "T: " . $transaction["tranId"];
                        $actions1 = json_decode($result_tran["actions"]);
                        foreach ($actions1 as $key => $value)
                        {
                            $actions[] = $value;
                        }
                        if ($result["share_fund"] == 0)
                        {
                            $result_pay = $momo->LoadData($row["phone"], $row["user_id"])->SendMoney($transaction["partnerId"], $check_game["amount_win"], $comments);
                            $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán tự động: " . $result_pay["message"] . ",SĐT: " . $row["phone"] . ",SD: " . number_format($result_pay["tranDList"]["balance"]) . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
                            $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`amount_paid` = '" . $check_game["amount_win"] . "' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            $data_send = $result_pay["full"];
                            writeLog($transaction["tranId"], "log.txt");
                            $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $row["user_id"] . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $data_send . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");
                            if ($result_pay["status"] != "success")
                            {
                                
                                $db->query("UPDATE `momo_history` SET   `status` = '2',`amount_paid` = '0' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            }
                        }
                        else
                        {
                            $result_withdraw_phone = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `withdraw_status` = '1'  AND `status` = 'success' AND `BALANCE` >= '" . $check_game["amount_win"] . "' AND `month`  + '" . $check_game['amount_win'] . "' <= `limit_month` AND `today` + '" . $check_game['amount_win'] . "' <= `limit_day` AND `user_id` = '" . $row["user_id"] . "' ORDER BY RAND() LIMIT 1", 1);
                            if (!$result_withdraw_phone["id"])
                            {
                                $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán tự động: Không có MOMO để trả.", ];
                                $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                                $db->query("UPDATE `momo_history` SET   `status` = '2', `actions` = '" . $insert_actions . "' ,`amount_paid` = '0' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            }
                            $result_pay = $momo->LoadData($result_withdraw_phone["phone"], $result_withdraw_phone["user_id"])->SendMoney($transaction["partnerId"], $check_game["amount_win"], $comments);
                            $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán tự động: " . $result_pay["message"] . ",SĐT: " . $row["phone"] . ",SD: " . number_format($result_pay["tranDList"]["balance"]) . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
                            $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`amount_paid` = '" . $check_game["amount_win"] . "' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            $data_send = $result_pay["full"];
                            writeLog($transaction["tranId"], "log.txt");
                            $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $row["user_id"] . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $data_send . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");
                            if ($result_pay["status"] != "success")
                            {
                                $db->query("UPDATE `momo_history` SET   `status` = '2',`amount_paid` = '0' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        die(json_encode(["status" => "error", "code" => - 99, "message" => "Không tồn tại tài khoản momo", ]));
    }
}
elseif ($act == "getHistoriesFull")
{
    $hours = POST("hours") ? : 2;
    $phone = $db->real_escape_string(junoo_boc(POST("phone")));
    $user_id = $db->real_escape_string(junoo_boc(POST("user_id")));
    $api_key = $db->real_escape_string(POST("api_key"));
    if ($phone)
    {
        $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `phone` = '" . $phone . "' AND `user_id` = '" . $user_id . "' ORDER BY `id` ASC LIMIT 1", 1);
        if (!$result["phone"])
        {
            die(json_encode(["status" => "error", "code" => - 99, "message" => "Không tồn tại tài khoản momo", ]));
        }
        $history = $momo->LoadData($result["phone"], $result["user_id"])->CheckHisNew($hours);
        echo "<pre>";
        print_r($history);
        echo "<pre>";
    }
    elseif ($type == 43926492)
    {
        $hours = POST("hours") ? : 2;
        $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `status` = 'success' ORDER BY `id` ASC ", 0);
        foreach ($result as $key => $row)
        {
            $history = $momo->LoadData($row["phone"], $row["user_id"])->CheckHisNew($hours);
            echo "<pre>";
            print_r($history);
            echo "<pre>";
            foreach ($history["TranList"] as $contents)
            {
                if ($contents["io"] == - 1)
                {
                    continue;
                }
                $transaction = ["time_tran" => $contents["millisecond"], "io" => $contents["io"], "tranId" => $contents["tranId"], "comment" => $contents["comment"], "amount" => $contents["amount"], "partnerId" => $contents["patnerID"], "partnerName" => $contents["partnerName"], "ID" => $contents["ID"], ];
                $exists = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id_momo` = '" . $transaction["ID"] . "' LIMIT 1 ", 1);
                $exists1 = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE `id_tran` = '" . $transaction["tranId"] . "' LIMIT 1 ", 1);
                $checkFile = strpos(file_get_contents("log.txt"),$transaction["tranId"]);
                if (!$exists["id"] && !$exists1["id"])
                //if (!$exists["id"] && !$exists1["id"] && !$checkFile)
                {
                    $game = [];
                    $actions = [];
                    $check_game = checkTransasion($transaction["tranId"], $transaction["amount"], $transaction["comment"], $row["user_id"], $transaction["partnerId"]);
                    $game[] = ["name" => $check_game["name"], "id_game" => $check_game["id_game"], "status_game" => $check_game["status_game"], "status" => $check_game["status"], "text" => $check_game["text"], "amount" => $transaction["amount"], "ratio" => $check_game["ratio"], "amount_win" => $check_game["amount_win"], "reciver" => $row["phone"], ];
                    $insert_game = json_encode($game, JSON_UNESCAPED_UNICODE);
                    $actions[] = ["time" => time() , "person" => "Hệ Thống", "text" => "Check đơn: " . $check_game["text"], ];
                    $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                    $insert = $db->query("INSERT INTO `momo_history` ( `user_id`, `phone`, `id_momo`, `id_tran`, `type`, `partnerId`, `partnerName`, `amount`, `comment`, `full_data`, `time_tran`, `time_tran_date`, `status_momo`, `created_at`, `updated_at`, `game`, `actions`, `status`,`amount_paid`,`try`) VALUES ( '" . $row["user_id"] . "', '" . $row["phone"] . "', '" . $transaction["ID"] . "', '" . $transaction["tranId"] . "', '" . $transaction["io"] . "', '" . $transaction["partnerId"] . "', '" . $transaction["partnerName"] . "', '" . $transaction["amount"] . "', '" . $transaction["comment"] . "', '" . json_encode($transaction) . "', '" . floor($contents["millisecond"] / 1000) . "', '" . date("d/m/Y H:i:s", floor($contents["millisecond"] / 1000)) . "', '999', current_timestamp(), current_timestamp() ,'" . $insert_game . "' , '" . $insert_actions . "','" . $check_game["status"] . "','0','0')");
                    $actions = [];
                    if ($check_game["status"] == 1)
                    {
                        $result_tran = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id_tran` = '" . $transaction["tranId"] . "' LIMIT 1", 1);
                        $comments = $row["noidungtra"] . "T: " . $transaction["tranId"];
                        $actions1 = json_decode($result_tran["actions"]);
                        foreach ($actions1 as $key => $value)
                        {
                            $actions[] = $value;
                        }
                        if ($result["share_fund"] == 0)
                        {
                            $result_pay = $momo->LoadData($row["phone"], $row["user_id"])->SendMoney($transaction["partnerId"], $check_game["amount_win"], $comments);
                            $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán tự động: " . $result_pay["message"] . ",SĐT: " . $row["phone"] . ",SD: " . number_format($result_pay["tranDList"]["balance"]) . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
                            $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`amount_paid` = '" . $check_game["amount_win"] . "' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            $data_send = $result_pay["full"];
                            writeLog($transaction["tranId"], "log.txt");
                            $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $row["user_id"] . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $data_send . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");

                            if ($result_pay["status"] != "success")
                            {
                                $db->query("UPDATE `momo_history` SET   `status` = '2',`amount_paid` = '0' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            }
                        }
                        else
                        {
                            $result_withdraw_phone = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `withdraw_status` = '1'  AND `status` = 'success' AND `BALANCE` >= '" . $check_game["amount_win"] . "' AND `month`  + '" . $check_game['amount_win'] . "' <= `limit_month` AND `today` + '" . $check_game['amount_win'] . "' <= `limit_day` AND `user_id` = '" . $row["user_id"] . "' ORDER BY RAND() LIMIT 1", 1);
                            if (!$result_withdraw_phone["id"])
                            {
                                $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán tự động: Không có MOMO để trả.", ];
                                $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                                $db->query("UPDATE `momo_history` SET   `status` = '2', `actions` = '" . $insert_actions . "' ,`amount_paid` = '0' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            }
                            $result_pay = $momo->LoadData($result_withdraw_phone["phone"], $result_withdraw_phone["user_id"])->SendMoney($transaction["partnerId"], $check_game["amount_win"], $comments);
                            $actions[] = ["time" => time() , "person" => "Hệ thống", "text" => "Thanh toán tự động: " . $result_pay["message"] . ",SĐT: " . $row["phone"] . ",SD: " . number_format($result_pay["tranDList"]["balance"]) . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
                            $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
                            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`amount_paid` = '" . $check_game["amount_win"] . "' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            $data_send = $result_pay["full"];
                            writeLog($transaction["tranId"], "log.txt");
                            $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $row["user_id"] . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $data_send . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");
                            if ($result_pay["status"] != "success")
                            {
                                $db->query("UPDATE `momo_history` SET   `status` = '2',`amount_paid` = '0' WHERE  `user_id` = '" . $row["user_id"] . "'  AND `id` = '" . $result_tran["id"] . "' ");
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        die(json_encode(["status" => "error", "code" => - 99, "message" => "Không tồn tại tài khoản momo", ]));
    }
}
elseif ($act == "thangbomay")
{
    $db->query("UPDATE `cron_momo` SET `today` = '0', `today_gd` = '0'");
}
elseif ($act == "conmemay")
{
    $db->query("UPDATE `cron_momo` SET `month` = '0'");
}
elseif ($act == "pay")
{
    $action = $db->real_escape_string(junoo_boc(POST("action")));
    if (!$action)
    {
        die(json_encode(["status" => "error", "code" => - 105, "message" => "Vui lòng chọn hành động cần thực hiện.", ]));
    }
    $phone = $db->real_escape_string(junoo_boc(POST("phone")));
    $user_id = $accounts['username'];
    $edit_id = $db->real_escape_string(junoo_boc(POST("edit_id")));
    $ratio = $db->real_escape_string(POST("ratio"));
    $amount = $db->real_escape_string(junoo_boc(POST("amount")));
    $tientra = $amount * $ratio;
    $where = "";
    if ($phone)
    {
        $where .= "AND `phone` = '" . $phone . "'";
    }

    $result_tran = $db->fetch_assoc("SELECT * FROM `momo_history` WHERE  `user_id` = '" . $user_id . "'  AND `id` = '" . $edit_id . "' LIMIT 1", 1);
    if (!$result_tran["id"])
    {
        die(json_encode(["status" => "error", "code" => - 101, "message" => "Không tồn tại giao dịch trên hệ thống.", ]));
    }
    if ($action == 3)
    {
        $actions1 = json_decode($result_tran["actions"]);
        foreach ($actions1 as $key => $value)
        {
            $actions[] = $value;
        }
        $actions[] = ["time" => time() , "person" => $user_id, "text" => "Hoàn thành đơn", ];
        $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
        $db->query("UPDATE `momo_history` SET `status` = '1',`actions` = '" . $insert_actions . "' WHERE  `user_id` = '" . $user_id . "'  AND `id` = '" . $edit_id . "' ");
        die(json_encode(["status" => "success", "message" => "Hoàn thành đơn thành công", ]));
    }
    $result = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE  `user_id` = '" . $user_id . "' $where ORDER BY RAND() LIMIT 1", 1);
    if (!$result["phone"])
    {
        die(json_encode(["status" => "error", "code" => - 99, "message" => "Không còn tài khoản momo để trả", ]));
    }
    if ($result_tran["status"] == 0 || $result_tran["status"] == 1 || $result_tran["status"] == 3 || $result_tran["status"] == 6)
    {
        die(json_encode(["status" => "error", "code" => - 102, "message" => "Đơn này ở trạng thái không thể trả / hoàn.", ]));
    }
    if ($tientra < 0)
    {
        die(json_encode(["status" => "error", "code" => - 103, "message" => "Có lỗi xảy ra ở bước tính tiền trả.", ]));
    }
    $actions1 = json_decode($result_tran["actions"]);
    foreach ($actions1 as $key => $value)
    {
        $actions[] = $value;
    }
    if ($action == 1)
    {
        $comments = $result["noidungtra"] . "T: " . $result_tran["id_tran"];
        $result_pay = $momo->LoadData($result["phone"], $result["user_id"])->SendMoney($result_tran["partnerId"], $tientra, $comments);
        $actions[] = ["time" => time() , "person" => $user_id, "text" => "Trả thưởng tay: " . $result_pay["message"] . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
        $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $user_id . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $result_pay["full"] . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");

        if ($result_pay["status"] == "success")
        {
            $db->query("UPDATE `momo_history` SET `status` = '1',`actions` = '" . $insert_actions . "',`amount_paid` = '" . $tientra . "' WHERE  `user_id` = '" . $user_id . "'  AND `id` = '" . $edit_id . "' ");
        }
        else
        {
            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`amount_paid` = '0' WHERE  `user_id` = '" . $user_id . "'  AND `id` = '" . $edit_id . "' ");
        }
        die(json_encode($result_pay));
    }
    else
    {
        $comments = $result["noidungtra"] . "HT: " . $result_tran["id_tran"];
        $result_pay = $momo->LoadData($result["phone"], $result["user_id"])->SendMoney($result_tran["partnerId"], $tientra, $comments);
        $actions[] = ["time" => time() , "person" => $user_id, "text" => "Hoàn tiền: " . $result_pay["message"] . ",TranID: " . $result_pay["tranDList"]["tranId"], ];
        $insert_actions = json_encode($actions, JSON_UNESCAPED_UNICODE);
        $db->query("INSERT INTO `send` (`id`, `momo_id`, `tranId`, `partnerId`, `partnerName`, `amount`, `comment`, `time`, `user_id`, `status`, `message`, `data`,`balance`,`ownerNumber`,`ownerName`,`type`) VALUES (NULL, '" . $result_pay["tranDList"]["ID"] . "', '" . $result_pay["tranDList"]["tranId"] . "', '" . $result_pay["tranDList"]["partnerId"] . "', '" . $result_pay["tranDList"]["partnerName"] . "', '" . $result_pay["tranDList"]["amount"] . "', '" . $result_pay["tranDList"]["comment"] . "', '" . time() . "', '" . $user_id . "', '" . $result_pay["status"] . "', '" . $result_pay["message"] . "', '" . $result_pay["full"] . "','" . $result_pay["tranDList"]["balance"] . "','" . $result_pay["tranDList"]["ownerNumber"] . "','" . $result_pay["tranDList"]["ownerName"] . "','1')");

        if ($result_pay["status"] == "success")
        {
            $db->query("UPDATE `momo_history` SET `status` = '3',`actions` = '" . $insert_actions . "',`amount_paid` = '" . $tientra . "' WHERE  `user_id` = '" . $user_id . "'  AND `id` = '" . $edit_id . "' ");
        }
        else
        {
            $db->query("UPDATE `momo_history` SET `actions` = '" . $insert_actions . "',`amount_paid` = '0' WHERE  `user_id` = '" . $user_id . "'  AND `id` = '" . $edit_id . "' ");
        }
        die(json_encode($result_pay));
    }
    
}
?>