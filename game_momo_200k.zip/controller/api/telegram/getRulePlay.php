<?php

require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$txt_phone = "";
$result = $db->fetch_assoc("SELECT * FROM `game` WHERE `username` = '".$settings['username']."' AND `status` = 'run' ORDER BY `id` DESC ",0);
foreach($result as $key => $row) {
$limit  = explode("|",$row['limit_play']);
$txt_phone .= "\nGame: ".$row['name']."\n\n";
$result1 = $db->fetch_assoc("SELECT * FROM `game_option` WHERE `game_id` = '".$row['id']."' AND `username` = '".$settings['username']."' AND `status` = 'run' ORDER BY `id` DESC ",0);
foreach($result1 as $key1 => $row1) {
    $kq = explode(",",$row1['result']); 
    $txtso = "";
    foreach($kq as $key2 => $row2) {
        $txtso .=    $row2.",";
    }
    $txtso = rtrim($txtso, ",");
    $txt_phone .= "Cú pháp: ".strtoupper($row1['comment'])." \nSố: ".$txtso."\nTiền nhận: x".$row1['ratio']."\n";
    $txt_phone .= "Tính KQ là ".$row1['number_comment']." chữ số cuối\n\n";
}

$txt_phone .= "<----------->\n";
}
$txt_phone = rtrim($txt_phone, "<----------->\n");
echo $txt_phone;