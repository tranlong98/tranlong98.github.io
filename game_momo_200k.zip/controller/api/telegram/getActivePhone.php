<?php

require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');


$result_phone = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `user_id` = '".$settings['username']."' AND `status` = 'success' AND `today` < `limit_day` AND `month` < `limit_month` ORDER BY RAND() LIMIT 10",0);
$txt_phone = "|         SĐT        |    Hạn Mức  |    Số GD \n";
foreach ($result_phone as $key3 => $value){
    //$txt_phone .= "Sđt: ".$value['phone']."\nHạn mức: ".number_format($value['today'])."\nSố GD: ".number_format($value['today_gd'])."/150\n";
$txt_phone .= "| ".$value['phone']." | ".number_format($value['today'])."  | ".number_format($value['today_gd'])."/150
|-------------------|------------------|-------------\n";
}
echo $txt_phone."\nLưu ý: Mỗi sdt 1 ngày chỉ giao dịch được 150 lần và 30tr. Khi đạt 130 gd hoặc 25tr hệ thống sẽ đổi số.";