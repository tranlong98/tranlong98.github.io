<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!is_client()) {
    die(json_encode(array(
        "status" => "error",
        "msg" => "Vui lòng đăng nhập trước nhé."
    )));
}

if (GET("act") == 'settings') {
    $id    = $db->real_escape_string(junoo_boc(POST("id")));
    $limit_play   = $db->real_escape_string(POST("limit_play"));
    $mota = $db->real_escape_string(POST("mota"));
    $name  = $db->real_escape_string(POST("name"));
    $status      = $db->real_escape_string(junoo_boc(POST("status")));
    if (!$limit_play || !$id || !$name || !$status) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    $data = $db->fetch_assoc("SELECT * FROM `game` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' LIMIT 1 ", 1);
    if (!$data['id']) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Không tồn tại lựa chọn hoặc lựa chọn không phải của bạn."
        )));
    }
    $db->query("UPDATE  `game` SET `limit_play` = '" . $limit_play . "',`status` = '" . $status . "',`mota` = '" . $mota . "',`name` = '" . $name . "' WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
    
} elseif (GET("act") == 'add') {
    $limit_play   = $db->real_escape_string(POST("limit_play"));
    $mota = $db->real_escape_string(POST("mota"));
    $name  = $db->real_escape_string(POST("name"));
    $status      = $db->real_escape_string(junoo_boc(POST("status")));
    if (!$limit_play  || !$name || !$status) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    
    $db->query("INSERT INTO  `game` SET `username` = '".$accounts['username']."', `limit_play` = '" . $limit_play . "',`status` = '" . $status . "',`mota` = '" . $mota . "',`name` = '" . $name . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
    
}elseif (GET("act") == 'auto_paid') {
    $status      = $db->real_escape_string(junoo_boc(POST("status")));
    if (!$status) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    if($status == 'on') {
        $status = 1;
    }else{
        $status = 0;
    }
    $db->query("UPDATE `settings` SET `auto_paid` = '" . $status . "' WHERE `username` = '".$settings['username']."'  ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
    
} else {
    $id = junoo_boc(POST("id"));
    if (!$id) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    $data = $db->fetch_assoc("SELECT * FROM `game` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' LIMIT 1 ", 1);
    if (!$data['id']) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Không tồn tại game hoặc game không phải của bạn."
        )));
    }
    $db->query("DELETE FROM  `game` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' ");
    $db->query("DELETE FROM  `game_option` WHERE `game_id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
}