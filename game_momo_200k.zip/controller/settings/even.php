<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!is_client()) {
    die(json_encode(array(
        "title" => "error",
        "msg" => "Vui lòng đăng nhập trước nhé."
    )));
}

if (GET("act") == 'settings') {
    $id    = $db->real_escape_string(POST("id"));
    $game    = $db->real_escape_string(POST("game"));
    $mota    = $db->real_escape_string(POST("mota"));
    $moc1   = $db->real_escape_string(POST("moc1"));
    $moc2 = $db->real_escape_string(POST("moc2"));
    $moc3  = $db->real_escape_string(POST("moc3"));
    $moc4  = $db->real_escape_string(POST("moc4"));
    $moc5  = $db->real_escape_string(POST("moc5"));
    $thuong1  = $db->real_escape_string(POST("thuong1"));
    $thuong2  = $db->real_escape_string(POST("thuong2"));
    $thuong3  = $db->real_escape_string(POST("thuong3"));
    $thuong4  = $db->real_escape_string(POST("thuong4"));
    $thuong5  = $db->real_escape_string(POST("thuong5"));
    $momotra  = $db->real_escape_string(POST("momotra"));
    $trangthai  = $db->real_escape_string(POST("status"));
    $db->query("UPDATE  `even` SET `game` = '" . $game . "',`mota` = '" . $mota . "',`moc1` = '" . $moc1 . "',`moc2` = '" . $moc2 . "',`moc3` = '" . $moc3 . "',`moc4` = '" . $moc4 . "',`moc5` = '" . $moc5 . "',`thuong1` = '" . $thuong1 . "',`thuong2` = '" . $thuong2 . "',`thuong3` = '" . $thuong3 . "',`thuong4` = '" . $thuong4 . "',`thuong5` = '" . $thuong5 . "',`momotra` = '" . $momotra . "' ,`trangthai` = '" . $trangthai . "' WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Update Even Thành Công"
    )));
    
    
}