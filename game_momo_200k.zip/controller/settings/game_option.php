<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!is_client()) {
    die(json_encode(array(
        "status" => "error",
        "msg" => "Vui lòng đăng nhập trước nhé."
    )));
}

if (GET("act") == 'settings') {
    $comment          = $db->real_escape_string(junoo_boc(POST("comment")));
    $id    = $db->real_escape_string(junoo_boc(POST("id")));
    $number_comment   = $db->real_escape_string(junoo_boc(POST("number_comment")));
    $type = $db->real_escape_string(junoo_boc(POST("type")));
    $result  = $db->real_escape_string(POST("result"));
    $ratio  = $db->real_escape_string(POST("ratio"));
    $status = $db->real_escape_string(junoo_boc(POST("status")));
    if (!$comment || !$id || !$number_comment || !$result || !$ratio || !$status) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    $data = $db->fetch_assoc("SELECT * FROM `game_option` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' LIMIT 1 ", 1);
    if (!$data['id']) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Không tồn tại lựa chọn hoặc lựa chọn không phải của bạn."
        )));
    }
    $db->query("UPDATE  `game_option` SET `comment` = '" . $comment . "',`status` = '" . $status . "',`number_comment` = '" . $number_comment . "',`type` = '" . $type . "',`result` = '" . $result . "',`ratio` = '" . $ratio . "' WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
    
} elseif (GET("act") == 'add') {
    $comment          = $db->real_escape_string(junoo_boc(POST("comment")));
    $number_comment   = $db->real_escape_string(junoo_boc(POST("number_comment")));
    $type = $db->real_escape_string(junoo_boc(POST("type")));
    $result  = $db->real_escape_string(POST("result"));
    $ratio  = $db->real_escape_string(POST("ratio"));
    $status      = $db->real_escape_string(junoo_boc(POST("status")));
    $id = $db->real_escape_string(junoo_boc(POST("id")));
    if (!$id || !$comment  || !$number_comment || !$ratio || !$status) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    $data = $db->fetch_assoc("SELECT * FROM `game` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' LIMIT 1 ", 1);
    if (!$data['id']) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Không tồn tại game hoặc game không phải của bạn."
        )));
    }
    $db->query("INSERT INTO  `game_option` SET `comment` = '" . $comment . "',`status` = '" . $status . "',`number_comment` = '" . $number_comment . "',`type` = '" . $type . "',`result` = '" . $result . "',`ratio` = '" . $ratio . "' ,`username` = '" . $accounts['username'] . "',`game_id` = '".$id."'  ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
    
} else {
    $id = junoo_boc(POST("id"));
    if (!$id) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Dữ liệu vào không hợp lệ."
        )));
    }
    $data = $db->fetch_assoc("SELECT * FROM `game_option` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' LIMIT 1 ", 1);
    if (!$data['id']) {
        die(json_encode(array(
            "status" => "error",
            "msg" => "Không tồn tại lựa chọn hoặc lựa chọn không phải của bạn."
        )));
    }
    $db->query("DELETE FROM  `game_option` WHERE `id` = '" . $id . "' AND `username` = '" . $accounts['username'] . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
}