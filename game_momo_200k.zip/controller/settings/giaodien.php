<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!is_client()) {
    die(json_encode(array(
        "title" => "error",
        "msg" => "Vui lòng đăng nhập trước nhé."
    )));
}

if (GET("act") == 'settings') {
    $apikey    = $db->real_escape_string(POST("apikey"));
    $keywords    = $db->real_escape_string(POST("keywords"));
    $title   = $db->real_escape_string(POST("title"));
    $description = $db->real_escape_string(POST("description"));
    $logo  = $db->real_escape_string(POST("logo"));
    $luuy  = $db->real_escape_string(POST("luuy"));
    $notice  = $db->real_escape_string(POST("notice"));
    $video  = $db->real_escape_string(POST("video"));
    $zalo  = $db->real_escape_string(POST("zalo"));
    $tele  = $db->real_escape_string(POST("tele"));
    $top  = $db->real_escape_string(POST("top"));
    $sapxep  = $db->real_escape_string(POST("sapxep"));
    $soluong  = $db->real_escape_string(POST("soluong"));
    $color  = $db->real_escape_string(POST("color"));
    $block_list  = $db->real_escape_string(POST("block_list"));
    $custom_footer  = $db->real_escape_string(POST("custom_footer"));
    $hidden_history      = $db->real_escape_string(junoo_boc(POST("hidden_history"))) ? 1 : 0;
    $view_top      = $db->real_escape_string(POST("view_top"));
    $color  = $db->real_escape_string(POST("color"));
    $db->query("UPDATE  `settings` SET `apikey` = '" . $apikey . "', `view_top` = '" . $view_top . "',`custom_footer` = '" . $custom_footer . "',`hidden_history` = '" . $hidden_history . "',`custom_footer` = '" . $custom_footer . "',`block_list` = '" . $block_list . "',`color` = '" . $color . "',`top` = '" . $top . "',`keywords` = '" . $keywords . "',`title` = '" . $title . "',`description` = '" . $description . "',`logo` = '" . $logo . "',`luuy` = '" . $luuy . "',`notice` = '" . $notice . "',`video` = '" . $video . "',`zalo` = '" . $zalo . "',`tele` = '" . $tele . "',`sapxep` = '" . $sapxep . "',`soluong` = '" . $soluong . "' WHERE `id` = '1' AND `username` = '" . $accounts['username'] . "' ");
    die(json_encode(array(
        "status" => "success",
        "msg" => "Thành Công"
    )));
    
    
}