<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$settings = $db->fetch_assoc("SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1", 1);
$top = explode(",",$settings['top']);
$domain = $_SERVER['HTTP_HOST']; 
?>
<!DOCTYPE html>
<html class="no-js" lang="vi">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title> <?=$settings['title']?> </title>
    <link href="https://i.imgur.com/hm7QMr7.png" rel="apple-touch-icon"/>
    <link href="https://i.imgur.com/hm7QMr7.png" rel="shortcut icon" type="image/x-icon"/>
    <!-- Required Meta Tags Always Come First -->
    <meta name="csrf-token" content="<?= $_SESSION['csrf-token'];?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="title" content="<?=$settings['title']?>" />
    <meta name="description" content="<?=$settings['description']?>" />
    <meta name="keywords" content="<?=$settings['keywords']?>" />
    <link rel="canonical" href="<?=$_DOMAIN?>">
    <meta name="robots" content="index, follow">
    <meta property="fb:app_id" content="" />
    <meta property="og:url" content="<?=$_DOMAIN?>">
    <meta property="og:type" content="article">
    <meta property="og:title" content="<?=$settings['title']?>">
    <meta property="og:description" content="<?=$settings['description']?>">
    <!--begin::Global Theme Styles(used by all pages)-->
    <link rel="stylesheet" href="/giaodien/frontend-user/assets/css2/bootstrap.min.css">
    <link rel="stylesheet" href="/giaodien/frontend-user/assets/css2/styleclmm.css">
    <link rel="stylesheet" href="/giaodien/frontend-user/assets/js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.css">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script> 
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
     
     <link href="https://codeseven.github.io/toastr/build/toastr.min.css" rel="stylesheet"/>
     
    <style>
        .panel-primary {
            border-color: <?=$settings['color']?>
        }

        .panel-primary>.panel-heading {
            color: #fff;
            background-color: <?=$settings['color']?>;
            border-color: <?=$settings['color']?>
        }
        
        .panel-primary>.panel-heading+.panel-collapse .panel-body {
            border-top-color: <?=$settings['color']?>
        }

        .panel-primary>.panel-footer+.panel-collapse .panel-body {
            border-bottom-color: <?=$settings['color']?>
        }
        .aa:hover,.aa:focus {
            background: <?=$settings['color']?>;
            border-radius: 5px
        }
        .bg-primary {
            color: #fff ;
            background-color: <?=$settings['color']?> !important;
        }
        
        .navbar {
          position:relative;
          /* z-index:501; */
          min-height:60px;
          margin-bottom:0;
          background-color:<?=$settings['color']?>;
          border:none;
          border-top-right-radius:0;
          border-top-left-radius:0;
          border-bottom-right-radius:0;
          border-bottom-left-radius:0;
        }
        .bg-grad-2 {
          background-color:<?=$settings['color']?>;
          box-shadow: 1px 2px 0px #a7002b;
        }
        .coffer-box {
            display: block;
            position: fixed;
            bottom: 90px;
            right: 15px;
            width: 15%;
            z-index: 1000;
            cursor: pointer;
            /*background: #ad410569;*/
            border-radius: 10px;
            text-align: center;
            padding: 15px;
        }
        @media (max-width: 767px) {
            .coffer-box {
                background: unset;
                width: 50%;
                bottom: 20px;
            }
        }
        .mb-0 {
            margin-bottom: 0;
        }
        .dot-text-1 {
            color: #f0ad4e
        }
        .dot-text-2 {
            color: #5bc0de
        }
        .dot-text-3 {
            color: #5cb85c
        }
        .dot-text-4 {
            color: #d9534f
        }
        
        .dot-text-6 {
            color: #5bc0de
        }
        .dot-text-7 {
            color: #5cb85c
        }
        .dot-text-8 {
            color: #d9534f
        }
        .dot-text-9 {
            color: #f0ad4e
        }
        
        .dot-text-11 {
            color: #5cb85c
        }
        .dot-text-12 {
            color: #d9534f
        }
        .dot-text-13 {
            color: #f0ad4e
        }
        .dot-text-14 {
            color: #5bc0de
        }
        
        .dot-text-16 {
            color: #d9534f
        }
        .dot-text-17 {
            color: #f0ad4e
        }
        .dot-text-18 {
            color: #5bc0de
        }
        .dot-text-19 {
            color: #5cb85c
        }
        
        </style>
  </head>
  <body>

    

        
        <div class="mainbar" style="height: 150px;">
        <div class="navbar">
            <div class="container">
                <div class="hidden-xs ">
                    <a href="/">
                        <img src="<?=$settings['logo']?>"  height="100px" alt="Logo">
                    </a>
                </div>
                <div class="visible-xs">
                    <a href="/">
                        <img src="<?=$settings['logo']?>"  height="100px" alt="Logo">
                    </a>
                </div>
                </li>
                </ul>
            </div>
        </div>
    </div>
    </div>
    
<div class="modal fade" id="result-check" tabindex="-1" role="dialog" style="overflow: scroll; -webkit-overflow-scrolling: touch;">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header text-center">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h3 class="modal-title">
<h3 class="text-danger"><b>Kiểm Tra Giao Dịch</b></h3>
</h3>
</div>
<div class="modal-body">
<p>Mã GD: <b style="color:#00cc66;" id="ls_magd">...</b></p>
<p>SĐT: <b style="color:brown;" id="ls_sdt">...</b></p>
<p>Số Tiền: <b style="color:#ff0066;" id="ls_sotien">...</b></p>
<p>Nội Dung: <b style="color:blue;" id="ls_noidung">...</b></p>
<hr style="margin-top: 25px; margin-bottom: 25px;">
<h3 class="text-success"><b>Thông Tin Trò Chơi</b></h3>
<div style="margin: 0px; float: center; border: 1px dashed rgb(226, 93, 219); padding: 5px;">
<p>Loại Trò Chơi: <b style="color:#ff0066;" id="ls_loaitrochoi">...</b></p>
<p>Kết Quả: <b style="color:#00cc66;" id="ls_ketqua">...</b></p>
<p>Tiền Nhận: <b style="color:#ff0066;" id="ls_tiennhan">...</b></p>
<p>Trạng Thái: <b style="color:#0000ff;" id="ls_trangthai">...</b></p>
<p>Thời Gian: <b style="color:#000000;" id="ls_thoigian">...</b></p>
</div>
<hr style="margin-top: 25px; margin-bottom: 25px;">
<h4 style="text-align: center;color: blue;padding: 5px;border: 3px #5621ae solid;border-radius: 5px;"><a href="<?=$settings['zalo']?>">👉 Hỗ Trợ 👈</a></h4>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" style="border-radius: 0;" data-dismiss="modal">Đóng</button>
</div>
</div>
</div>
</div>
    
        <div class="container">
        <div class="content">
            <div class="content-container">
                <div style="min-height:80px !important;">
                    <div class="output" id="output">
                        <h2 class="font-weight-bold text-primary-2">Hệ Thống Chẵn Lẻ MoMo Tự Động VN</h2>
                        <h4 class="cursor text-gray-700"></h4>
                        <strong class="text-primary-2">Chỉ chơi số tại trang hệ thống hoàn toàn tự động, Xem lưu ý trước khi chơi</strong>

                    </div>
                    <div class="text-center mt-3">
                        <button type="button" class="btn btn-danger" data-toggle="modal"
                            data-target="#noticeModal">Xem Lưu Ý</button>
                            
                                                               
                                                   
                    </div>
                    
                    
                </div>
        <div class="text-center mt-5">
             <?php 
                      $result = $db->fetch_assoc("SELECT * FROM `game` WHERE `username` = '".$settings['username']."' AND `status` = 'run' ORDER BY `id` ASC ",0);
                      $data = array();
                        foreach($result as $key => $row) {
                      ?> 
                      
                      <button class="btn btn-default" server-action="change" server-id="<?=$row['id']?>" server-rate="<?=$row['id']?>"> <?=$row['name']?> </button> 
                     
                     <?php }?>
                     </div>
                
                <div class="text-center mt-5">
                    
                        <center>
                                     <?php 
                                      $result = $db->fetch_assoc("SELECT * FROM `even` WHERE `username` = '".$settings['username']."' AND `trangthai` = 'run'  ORDER BY `id` ASC ",0);
                                      $data = array();
                                        foreach($result as $key => $row) {
                                      ?> 
                                <div class="btn-group btn-group-lg" role="group" aria-label="...">      
                <button style="display:block" class="btn btn-primary" server-action="change" server-id="even<?=$row['id']?>" server-rate="even<?=$row['id']?>"><?=$row['game']?>
                <b style="
                            top: 22px; position: absolute;
                            margin-left: auto;
                            margin-right: auto;
                            left: 0;
                            right: 0;
                            text-align: center;
                            font-size: 7px;">
                <font color="red">(NEW)</font>
                </b>
                </button>
                </div> 
                                     <?php }?>
                            </center>
                       
                </div>
                
                     
          
          <div class="row justify-content-md-center box-cl">
             <div class="col-md-6 mt-3 cl">
              <div class="panel panel-primary">
                <div class="panel-heading text-center font-weight-bold">Cách chơi</div> 
              <?php 
                      $result = $db->fetch_assoc("SELECT * FROM `game` WHERE `username` = '".$settings['username']."' AND `status` = 'run' ORDER BY `id` DESC ",0);
                        foreach($result as $key => $row) {
                        $limit  = explode("|",$row['limit_play']);
                      ?> 
                      <div class="panel-body turn" turn-tab="<?=$row['id']?>" style="padding-top: 0px;"> 
                      <?=$row['mota']?> 
                      Cách chơi vô cùng đơn giản : <br> 
                      - Chuyển tiền vào một trong các tài khoản ở <a href="#list" ><code> danh sách số</code></a> bên dưới <br> 
                    <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover text-center">
                      <thead>
                        <tr role="row" class="bg-primary">
                          <th class="text-center text-white">Số điện thoại</th>
                          <th class="text-center text-white">Cược tối thiểu</th>
                          <th class="text-center text-white">Cược tối đa</th>
                        </tr>
                      </thead>
                      <tbody role="alert" aria-live="polite" aria-relevant="all" id="result-table" class=""> <?php
                                    $result_phone = $db->fetch_assoc("SELECT * FROM `cron_momo` WHERE `user_id` = '".$settings['username']."' AND `status` = 'success' AND `today_gd` < `ghbank` AND `today` < `limit_day` AND `month` < `limit_month` ORDER BY `id` DESC LIMIT 5",0);

                                       foreach ($result_phone as $key3 => $value){
                                       ?> <tr>
                          <td id="<?=$value['id']?>">
                                <b id="junoo_<?=$value['id']?>" style="
    position: relative;
                           "><?=$value['phone']?><b style="position: absolute;
    top: 15px;
    /* left: 1%; */
    /* margin: auto; */
    margin-left: auto;
    margin-right: auto;
    left: 0;
    right: 0;
    text-align: center;
    font-size: 9px;"><font color="green"><?=number_format($value['today'])?></font>/<font color="6861b1"><?=number_format($value['limit_day'])?></font>|<font color="green"><?=number_format($value['today_gd'])?></font>/<font color="6861b1"><?=number_format($value['ghbank'])?></font></b></b>
                            <span class="label label-success text-uppercase" onclick="copyStringToClipboard('<?=$value['phone']?>')">
                              <i class="fa fa-clipboard" aria-hidden="true"></i>
                            </span> 
                          </td>
                          <td><?=number_format($limit[0])?> VNĐ</td>
                          <td><?=number_format($limit[1])?> VNĐ</td><tr> <?php } ?> </tbody>
                    </table>
                    </div>
                     
                    <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover text-center">
                      <thead>
                        <tr role="row" class="bg-primary">
                          <th class="text-center text-white">Nội dung</th>
                          <th class="text-center text-white">Số</th>
                          <th class="text-center text-white">Tiền nhận</th>
                        </tr>
                      </thead>
                      <tbody role="alert" aria-live="polite" aria-relevant="all" id="result-table" class=""> 
                      <?php 
                      $result1 = $db->fetch_assoc("SELECT * FROM `game_option` WHERE `game_id` = '".$row['id']."' AND `username` = '".$settings['username']."' AND `status` = 'run' ORDER BY `id` DESC ",0);
                        $k=0;
                        foreach($result1 as $key1 => $row1) {
                        $k++;
                        ?> 
                      <tr>
                          <td>
                              <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-<?=$k?>"> </span><span class="fa-stack-1x text-white" id=""><b> <?=strtoupper($row1['comment'])?> </b></span></span>
                          </td>
                          <td> <?php $i = 0;$kq = explode(",",$row1['result']); foreach($kq as $key2 => $row2) { $i++; ?> <span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-<?=$i?>"> </span><span class="fa-stack-1x text-white" id=""><?=$row2?></span></span>
                          
                          <?php }?> </td>
                          <td>
                            <b>x<?=$row1['ratio']?></b>
                          </td>
                        </tr> <?php } ?> </tbody>
                    </table>
                  </div> - <b>Lưu ý:</b> Số tiền nhỏ nhất là <b> <?=number_format($limit[0])?> </b> và lớn nhất <b> <?=number_format($limit[1])?> </b>, nếu chuyển nhỏ hơn hoặc lớn hơn sẽ không được hoàn tiền. </div> 
                  <?php } ?>
                  
                  
                  <!----even----->
                   <?php 
                      $result = $db->fetch_assoc("SELECT * FROM `even` WHERE `username` = '".$settings['username']."' AND `trangthai` = 'run' ORDER BY `id` DESC ",0);
                        foreach($result as $key => $row) {
                      ?> 
                      <div class="panel-body turn" turn-tab="even<?=$row['id']?>" style="padding-top: 0px;"> 
                   <div class="body">
                        <div class="text-center"> <font color="blue"><big><b><?=$row['game']?></b></big></font>
                            <br>
                           <?php  if($row['id'] == '1'){ ?>
                            <div class="form-group occard" id="osdt">
                                <label for="exampleInputEmail1">Số điện thoại:</label>
                                <input type="text" class="form-control" id="PhoneChoi" aria-describedby="emailHelp" placeholder="09888888"> <small id="emailHelp" class="form-text text-muted">Nhập số điện thoại của bạn để điểm danh.</small>
                                <br>
                                <button type="button" id="submit1" name="submit1" class="btn btn-success" data-toggle="modal" data-target="#modalDiemDanh" onclick="choilanhan()">Kiểm Tra</button>
                            </div>
                            <?php } ?>
                            <?php  if($row['id'] == '2'){ ?>
                            <div class="form-group occard" id="osdt"> 
                    <label for="exampleInputEmail1">Mã giao dịch hoặc SĐT người chơi:</label> 
                    <input type="text" class="form-control" id="PhoneChoia" aria-describedby="emailHelp" placeholder="Mã giao dịch momo hoặc SĐT người chơi"> 
                    <small id="emailHelp" class="form-text text-muted">Nhập bất kỳ mã giao dịch nào của người bạn giới thiệu hoặc số điện thoại bạn giới thiệu,nếu nhập sdt là số cũ vd: 082xxx -> 0129xxx , 03xxx -> 016....</small> 
                    <br> 
                    <button type="button" id="submit2" name="submit2" class="btn btn-primary mt-1 rounded-pill font-weight-bold" data-toggle="modal" data-target="#modalDiemDanh" onclick="choilanhan2()">Kiểm Tra</button> </div> 
                    <div class="form-group occard" id="osdt"> 
                    <label for="exampleInputEmail1">Số điện thoại nhận thưởng:</label> 
                    <input type="text" class="form-control" id="phonenhan" aria-describedby="emailHelp" placeholder="0988668899"> 
                    <small id="emailHelp" class="form-text text-muted">Nhập số điện thoại của bạn để nhận thưởng.</small> 
                    <br> 
                    <button type="button" id="submit3" name="submit3" class="btn btn-success" data-toggle="modal" data-target="#modalDiemDanh" onclick="choilanhan3()">Nhận Thưởng</button> </div> 
                    <?php } ?>
                            
                            <div class="form-group occard" id="othuong" style="display:none;"> </div>
                        </div>
                        <div class="occho" id="fghdh">   <?=$row['mota']?> 
       
                        <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover text-center">
                                    <thead>
                                        <tr role="row" class="bg-primary">
                                            <th class="text-center text-white">Mốc chơi</th>
                                            <th class="text-center text-white">Thưởng</th>
                                    </tr></thead><tbody id="zzxc">
                                    <tr><td><?=$row['moc1']?></td> <td>+<?=$row['thuong1']?></td></tr>
                                    <tr><td><?=$row['moc2']?></td> <td>+<?=$row['thuong2']?></td></tr>
                                    <tr><td><?=$row['moc3']?></td> <td><font color="red">+<?=$row['thuong3']?></font></td></tr>
                                    <tr><td><?=$row['moc4']?></td> <td><font color="red">+<?=$row['thuong4']?></font></td></tr>
                                    <tr><td><?=$row['moc5']?></td> <td><font color="red">+<?=$row['thuong5']?></font></td></tr>
                                    </tbody>
                                </table>
                            </div>	
                      </div>
                 </div>
            </div> 
                  <?php } ?>
                  
              </div>
            </div>
            
            <div class="col-md-6 mt-3 cl">
                                        <div class="panel panel-primary">
                                            <div class="panel-heading text-center font-weight-bold">
                                                Kiểm tra mã giao dịch
                                            </div>
                                            <div class="panel-body text-center">
                                         <center><small class="form-text text-muted"><b>Lưu ý: <font color="red"> KHÔNG NÊN</font> chơi số Momo đang <span class="label label-danger text-uppercase">BẢO TRÌ</span></font> hãy chơi số đang <span class="label label-success text-uppercase">HOẠT ĐỘNG</span></font> phía dưới</b>.</center><center><b>Khi đạt 180 GD hoặc 30 Triệu Bank Hệ thống sẽ tự đổi số hoặc bảo trì số.</b></small></center>
                 <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover text-center">
                      <thead>
                        <tr role="row" class="bg-primary">
                          <th class="text-center text-white">Số điện thoại</th>
                          <th class="text-center text-white">Trạng thái</th>
                          <th class="text-center text-white">Hạn mức</th>
                          <th class="text-center text-white">Số GD</th>
                        </tr>
                      </thead>
                      
                      <tbody role="alert" id="0X2134X555" aria-live="polite" aria-relevant="all" id="result-table" class=""> 
                   
                      </tbody>
                     
                    </table>
                             
                  </div>
                
                                                <small class="alert alert-danger text-left" style="display: block;"> Nếu quá 10' chưa nhận được tiền vui lòng dán mã vào bên dưới kiểm tra. </small>
                  <div class="text-center">
                    <form role="form" id="check_tranid" method="" >
                    <div class="form-group">
                      <label for="tran_id">Nhập mã giao dịch của bạn để kiểm tra.</label>
                      <input type="number" class="form-control"  id="tran_id" name="tran_id" placeholder="Mã giao dịch: Ví dụ 11223344556">
                      
                      <button type="button" id="submit" name="submit" class="btn btn-primary mt-1 rounded-pill font-weight-bold" onclick="check_tranid()">Kiểm tra</button>
                    </div>
                    </form>
                  </div>
                  <br>
                  <p>
                    
                    <?php if($settings['zalo']) {?>
                            <a class="text-white" href="<?=$settings['zalo']?>"
                                                            target="_blank"><span
                                                                class="btn btn-primary rounded-pill">Admin Zalo</span></a>
                                                                <?php } ?>
                                                                 <?php if($settings['tele']) {?>
                            <a class="text-white" href="<?=$settings['tele']?>"
                                                            target="_blank"><span
                                                                class="btn btn-google rounded-pill">Box Lộc Telegram</span></a>
                                                                <?php } ?>
                  </p>
                
              </div>
            </div>
          </div>
           </div>
          <?php if($settings['hidden_history'] == 1) { ?>
          <hr style="margin-top: 25px; margin-bottom: 25px;">
          <div class="row" id="list">
           <div class="col-md-12">
              
                <div class="text-center mb-3">
                       <h3 class="text-uppercase">LỊCH SỬ THẮNG</h3>
                </div>
                <h5 style="color:black;font-weight: bold;text-align:center;" id="timer">(Cập nhật liên tục) <img src="/loading_ab.jpeg" width="23px"></h5>
                
                    
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover text-center">
                <thead>
                  <tr role="row" class="bg-primary">
                     
                    <th class="text-center text-white">Thời gian</th>
                    <th class="text-center text-white">Số điện thoại</th>
                    <th class="text-center text-white">Tiền cược</th>
                    <th class="text-center text-white">Trò chơi</th>
                    <th class="text-center text-white">Nội dung </th>
                    <th class="text-center text-white">Trạng thái</th>
                  </tr>
                </thead>
               <tbody role="alert" id="0X2134X453" aria-live="polite" aria-relevant="all" class="">
                </tbody>
              </table>
            
          
        </div>
        </div>
         </div>
          <?php }?>
          
          
          <hr style="margin-top: 25px; margin-bottom: 25px;">
          <div class="row" id="list">
            <div class="col-md-6">
                <div class="mt-5">
                    <div class="text-center mb-3">
                  <h3 class="text-uppercase">LƯU Ý</h3>
                </div>
              <div class="panel panel-primary week_top">
                
            <?=$settings['luuy']?>
              </div>
              
            
            </div>
            </div>
            <div class="col-md-6">
                <div class="mt-5">
                <div class="text-center mb-3">
                      <h3 class="text-uppercase">DANH SÁCH TOP <?php if($settings['view_top'] == 0){?>THÁNG<?php }else{ ?>TUẦN<?php }?></h3>

                </div>

                
                <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover text-center">
                    <thead>
                        <tr role="row" class="bg-primary">
                            <th class="text-center text-white">#</th>
                            <th class="text-center text-white">Người chơi</th>
                            <th class="text-center text-white">Tiền chơi</th>
                            <th class="text-center text-white">Phần thưởng</th>
                            
                        </tr>
                    </thead>
                    <tbody role="alert" aria-live="polite" aria-relevant="all" id="week_top" class="text-center">
            
                
                <?php
                if($settings['view_top'] == 0){
                    $ngaydaucuathang = strtotime(date('01-m-Y'));
                    $ngaycuoicuathang = strtotime('23:59:59 '.date('t-m-Y'));
                    $result_momo_history = $db->fetch_assoc("SELECT SUM(amount), partnerName, partnerId FROM `momo_history` WHERE `status_momo` = '999' AND  `user_id` = '".$settings['username']."' AND `time_tran` >= '".$ngaydaucuathang."'  AND `time_tran` <= '".$ngaycuoicuathang."'  GROUP BY `partnerId` ORDER BY SUM(amount) DESC LIMIT 5",0);
                }else{
                    $ngaydaucuatuan = getTimeStartTuan();
                    $ngaycuoicuatuan = getTimeEndTuan();
                    $result_momo_history = $db->fetch_assoc("SELECT SUM(amount), partnerName, partnerId FROM `momo_history` WHERE `status_momo` = '999' AND `user_id` = '".$settings['username']."' AND `time_tran` >= '".$ngaydaucuatuan."'  AND `time_tran` <= '".$ngaycuoicuatuan."'   GROUP BY `partnerId` ORDER BY SUM(amount) DESC LIMIT 5",0);
                }
                $i = 0;
                foreach ($result_momo_history as $key3 => $value){
                                $i++;   
                              ?> 
                              <tr>
                              <td><?php 
                              if($i == '1'){
                              echo '<img src="giaodien/frontend-user/assets/img/1.png">';
                              }elseif($i == '2'){
                                 echo '<img src="giaodien/frontend-user/assets/img/2.png">'; 
                              }elseif($i == '3'){
                                 echo '<img src="giaodien/frontend-user/assets/img/3.png">'; 
                              }elseif($i == '4'){
                                  echo '<span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-4"> </span><span class="fa-stack-1x text-white" id=""><b> 4 </b></span></span>'; 
                              }elseif($i == '5'){
                                  echo '<span class="fa-stack"><span class="fa fa-circle fa-stack-2x dot-text-5"> </span><span class="fa-stack-1x text-white" id=""><b> 5 </b></span></span>';
                              }
                              
                              ?>
                                  </td>
                              <td><?=substr($value['partnerId'],0,-5)?>**** </td>
                              <td> <?=number_format($value['SUM(amount)'])?> vnđ</td>
                              <td>+<font color="blue"><b><?=number_format($top[$i-1]);?></font></b> Momo </td>
                              
                             </tr>
                                    <?php
                              }
                              ?>
                                
                              
                                
                                                </tbody>
                </table>
                <div class="text-center">
                <?php
                if($settings['view_top'] == 0){
                    echo'<b class="text-danger">Phần thưởng TOP sẽ được trao tự động vào 01:00 AM ngày cuối tháng.</b>';
                }else{
                    echo'<b class="text-danger">Phần thưởng TOP sẽ được trao tự động vào 01:00 AM ngày cuối tuần.</b>';
                }
                 ?>
                
            </div>
                                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="modalGift" tabindex="-1" role="dialog" style="overflow: scroll; -webkit-overflow-scrolling: touch;">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
            <h3 class="modal-title">
              <h2 class="text-danger">
                <b>PHẦN THƯỞNG TOP</b>
              </h2>
            </h3>
          </div>
          <div class="modal-body">
            <p>TOP sẽ dược trao vào 23h55 ngày cuối của <?php if($settings['view_top'] == 0){?>THÁNG<?php }else{ ?>TUẦN<?php }?>.</p>
            <p>Phần thưởng top :</p> <?php for($i=0;$i < count($top);$i++) { ?> <p>- TOP <?=$i+1?> : <?=number_format($top[$i]);?> </p> <?php }?>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" style="border-radius: 0;" data-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>
<footer class="footer bg-grad-2">
<div class="container text-center">
<div class="row">
<div class="col-xs-12">
<img src="<?=$settings['logo']?>" alt="logo-footer" width="150px">
</div>
<div class="col-xs-12 text-white ">
Copyright <a style="color: white;" href="#"><?=$domain?></a>
</div>
</div>
</div>
</footer>
    <script src="/giaodien/frontend-user/assets/js/libs/jquery-1.10.1.min.js"></script>
    <script src="/giaodien/frontend-user/assets/js/libs/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="/giaodien/frontend-user/assets/js/jquery.validate.min.js"></script>
    <script src="/giaodien/frontend-user/assets/js/libs/bootstrap.min.js"></script>
    <script src="https://codeseven.github.io/toastr/glimpse.toastr.js"></script>
     <script src="https://codeseven.github.io/toastr/build/toastr.min.js"></script>
    <script src="/giaodien/frontend-user/assets/js/111.js"></script>
    <!-- Modal -->

    <div class="modal fade" id="noticeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title text-center font-weight-bold text-primary-2" id="exampleModalLongTitle">Thông Báo</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="modal-body">
    <?=$settings['notice']?> 
    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary rounded-pill" data-dismiss="modal">Đã
                    hiểu</button>
            </div>
        </div>
    </div>
</div>
    
    <script>

 $(document).ready(function() {
        $('#noticeModal').modal('show')
        $('[data-toggle="tooltip"]').tooltip()
      });
    </script>

    
    <?=$settings['custom_footer']?>

  </body>
</html>